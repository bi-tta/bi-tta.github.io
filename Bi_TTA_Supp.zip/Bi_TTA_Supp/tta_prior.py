"""
Copyright to SAR Authors, ICLR 2023 Oral (notable-top-5%)
built upon on Tent code.
"""

from copy import deepcopy

import torch
import torch.nn as nn
import torch.jit
import math
import numpy as np
import os
from time import time
import MyPrior
from torch.nn.functional import cosine_similarity
import MyLoss
from scipy.stats import pearsonr

torch.autograd.set_detect_anomaly(True)


def update_ema(ema, new_data):
    if ema is None:
        return new_data
    else:
        with torch.no_grad():
            return 0.9 * ema + (1 - 0.9) * new_data

# haodongli, EMA
def update_ema_variables(model, ema_model, alpha):
    # Use the true average until the exponential average is more correct
    # alpha = min(1 - 1 / (global_step + 1), alpha)
    alpha = alpha
    with torch.no_grad():
        model_state_dict = model.state_dict()
        ema_model_state_dict = ema_model.state_dict()

        for entry in model_state_dict.keys():
            ema_param = ema_model_state_dict[entry].clone().detach()
            param = model_state_dict[entry].clone().detach()

            # Interpolation
            # 和动量不一样
            new_param = (ema_param * alpha) + (param * (1. - alpha))

            model_state_dict[entry] = new_param

        model.load_state_dict(model_state_dict)


class TTA_Prior(nn.Module):
    """SAR online adapts a model by Sharpness-Aware and Reliable entropy minimization during testing.
    Once SARed, a model adapts itself by updating on every forward.
    """
    def __init__(self, model, optimizer, steps=1, episodic=False, margin_e0=0.4*math.log(1000), 
                 reset_constant_em=0.2, tta_step=-1, iter_num=-1, save_grad=False, tta_method="prior",
                 ema_param=0.05, param_weights=None, l_opt_k=1.0, backtrack_degree=1.0, args=None,
                 base_optimizer=None, disable_bd=False, sim_matrix='cosine', weighted_trend=False):
        super().__init__()
        self.model = model
        self.optimizer = optimizer
        self.steps = steps
        assert steps > 0, "TTA_Prior requires >= 1 step(s) to forward and update"
        self.episodic = episodic

        self.margin_e0 = margin_e0  # margin E_0 for reliable entropy minimization, Eqn. (2)
        self.reset_constant_em = reset_constant_em  # threshold e_m for model recovery scheme
        self.ema = None  # to record the moving average of model output entropy, as model recovery criteria

        # haodongli, for saving grads
        self.tta_step = tta_step
        self.iter_num = iter_num
        self.save_grad = save_grad

        # haodongli, prior
        self.TCLoss = None
        self.SCLoss = None
        self.loss_list = []
        self.tta_method = tta_method
        if 'TODO' in self.tta_method:
            self.sim_list = []
            # same as tta_method in ["bitta_si_ema_prior", "si_ema_prior"]
            self.history_grads = None
            self.grads_norm_list = []
            self.grads_std_list = []
            self.sim_matrix = sim_matrix

        # haodongli, EMA
        self.ema_model = model
        self.ema_param = ema_param
        print(f"==> set self.ema_param = {self.ema_param}")

        # haodongli, SI
        # if tta_method in ["bitta_si_ema_prior", "si_ema_prior"]:
        if 'si' in tta_method or 'abl' in tta_method:
            self.base_optimizer = base_optimizer
            # assert param_weights != None, f"Invalid param_weights, should not be {param_weights}"
            # self.l_opt_weights = param_weights
            # # self.l_opt_weights = [0.0 for _ in param_weights] # temp, ablation
            # self.opt_l_weights = [1.0/weight for weight in param_weights]
            # # self.opt_l_weights = [0.0 for _ in param_weights] # temp, ablation
            self.l_opt_k = l_opt_k
            # new, backtracking
            self.history_grads = None # []
            self.backtrack_degree = backtrack_degree
            print(f"==> tta_method is {tta_method}, backtrack_degree = {backtrack_degree}")
            self.RegLoss = MyPrior.ModelParamReg()
            self.disable_bd = disable_bd
            # self.sim_matrix = sim_matrix
        if 'GT' in tta_method:
            self.args = args

        self.weighted_trend = weighted_trend
        print(f"==> self.weighted_trend = {self.weighted_trend}")

        # note: if the model is never reset, like for continual adaptation,
        # then skipping the state copy would save memory
        self.model_state, self.optimizer_state = \
            copy_model_and_optimizer(self.model, self.optimizer)

    def set_prior_loss(self, k15, k16, k17, k18, save_path):
        self.TCLoss = MyPrior.temporal_loss(k15)
        self.SCLoss = MyPrior.SpatialConsistencyLoss2()
        self.k16 = k16
        self.k17 = k17
        self.k18 = k18
        self.save_path = save_path
        print(f"==> in TTA_Prior, k16={self.k16}, save_path={self.save_path}, step={self.steps}")
        print(f"==> in TTA_Prior, k17={self.k17}, k18={self.k18}")

    def set_info(self, tta_step=-1, iter_num=-1, save_grad=False, total_iter=0, total_iter_sam=0):
        self.tta_step = tta_step
        self.iter_num = float(iter_num)
        self.save_grad = save_grad
        self.total_iter = float(total_iter)
        self.total_iter_sam = float(total_iter_sam)
        # if tta_step == 0:
        #     print(f"==> in TTA_Prior set_info(), self.iter_num = {self.iter_num}, self.total_iter = {self.total_iter}, self.total_iter_sam = {self.total_iter_sam}")

    def merge_grads(self, current_grads):
        if self.history_grads == None:
            self.history_grads = current_grads
        # elif current_grads == None:
        #     pass
        else:
            if current_grads == None:
                print('here!!!')
                current_grads = [None for _ in self.history_grads]
            for i, grad in enumerate(current_grads):
                if grad == None: continue
                # Concatenate the two tensors
                # combined = torch.cat((self.history_grads[i], grad))
                # Calculate the mean
                # grad_mean = torch.mean(combined)
                grad_mean = (self.history_grads[i] + grad)/2.0
                self.history_grads[i] = grad_mean # torch.mean(grad_mean)

    def merge_grads_weighted(self, current_grads, loss):
        loss = loss.detach().cpu().numpy()
        if self.history_grads == None:
            self.history_grads = current_grads
        # elif current_grads == None:
        #     pass
        else:
            for i, grad in enumerate(current_grads):
                if grad == None: continue
                # Concatenate the two tensors
                # combined = torch.cat((self.history_grads[i], grad))
                # Calculate the mean
                # grad_mean = torch.mean(combined)
                # breakpoint()
                grad_mean = (self.history_grads[i] + (1.0/loss)*grad)/(1.0 + (1.0/loss))
                self.history_grads[i] = grad_mean # torch.mean(grad_mean)


    def forward(self, x, x_aug):
        if self.episodic:
            self.reset()

        tta_step, iter_num = self.tta_step, self.iter_num
        self.loss_list = []

        for _ in range(self.steps):
            if self.tta_method == 'prior':
                outputs, ema, reset_flag, loss = forward_and_adapt_prior(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                                         self.model, self.optimizer, 
                                                                         self.margin_e0, 
                                                                         self.reset_constant_em, self.ema,
                                                                         TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                                         k16=self.k16, save_path=self.save_path)
            elif self.tta_method == 'gt_TODO':
                raise NotImplementedError
            elif self.tta_method == 'prior_TODO':
                # raise NotImplementedError
                outputs, ema, reset_flag, loss, sim, grads, grads_norm, grads_std = \
                    forward_and_adapt_prior_TODO(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                 self.model, self.optimizer, 
                                                 self.margin_e0, 
                                                 self.reset_constant_em, self.ema,
                                                 TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                 k16=self.k16, save_path=self.save_path,
                                                 history_grads=self.history_grads,
                                                 sim_matrix=self.sim_matrix,
                                                 anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter))
                
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == 'ema_prior':
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss = forward_and_adapt_prior(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                                         self.model, self.optimizer, 
                                                                         self.margin_e0, 
                                                                         self.reset_constant_em, self.ema,
                                                                         TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                                         k16=self.k16, save_path=self.save_path)
            elif self.tta_method == 'bitta_prior':
                outputs, ema, reset_flag, loss = forward_and_adapt_prior_bitta(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                                             self.model, self.optimizer, 
                                                                             self.margin_e0, 
                                                                             self.reset_constant_em, self.ema,
                                                                             TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                                             k16=self.k16, save_path=self.save_path)
            elif self.tta_method == 'bitta_prior_TODO':
                outputs, ema, reset_flag, loss, sim, grads, grads_norm, grads_std = \
                    forward_and_adapt_prior_bitta_TODO(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                     self.model, self.optimizer, 
                                                     self.margin_e0, 
                                                     self.reset_constant_em, self.ema,
                                                     TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                     k16=self.k16, save_path=self.save_path,
                                                     history_grads=self.history_grads,
                                                     sim_matrix=self.sim_matrix,
                                                     anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter))
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == 'bitta_GT_TODO':
                outputs, ema, reset_flag, loss, sim, grads, grads_norm, grads_std = \
                    forward_and_adapt_GT_bitta_TODO(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                  self.model, self.optimizer, 
                                                  self.margin_e0, 
                                                  self.reset_constant_em, self.ema,
                                                  TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                  k16=self.k16, save_path=self.save_path,
                                                  history_grads=self.history_grads,
                                                  args=self.args, sim_matrix=self.sim_matrix,
                                                  anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter))
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == 'bitta_ema_prior':
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss = forward_and_adapt_prior_bitta(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                                             self.model, self.optimizer, 
                                                                             self.margin_e0, 
                                                                             self.reset_constant_em, self.ema,
                                                                             TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                                             k16=self.k16, save_path=self.save_path)
            elif self.tta_method == 'bitta_ema_prior_TODO':
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss, sim, grads, grads_norm, grads_std \
                    = forward_and_adapt_prior_bitta_TODO(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                       self.model, self.optimizer, 
                                                       self.margin_e0, 
                                                       self.reset_constant_em, self.ema,
                                                       TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                       k16=self.k16, save_path=self.save_path,
                                                       history_grads=self.history_grads,
                                                       sim_matrix=self.sim_matrix,
                                                       anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter))
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == 'bitta_ema_prior_abl_1':
                # certified, same as SAR_EMA_Prior
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss = \
                    forward_and_adapt_prior_bitta_abl_1(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                      self.model, self.optimizer, 
                                                      self.margin_e0, 
                                                      self.reset_constant_em, self.ema,
                                                      TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                      k16=self.k16, save_path=self.save_path)
            elif self.tta_method == 'bitta_ema_prior_abl_2':
                # TODO certifying that tclscl == tclscl + 0*regularization
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss = \
                    forward_and_adapt_prior_bitta_abl_2(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                      self.model, self.optimizer, 
                                                      self.margin_e0, 
                                                      self.reset_constant_em, self.ema,
                                                      TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                      k16=self.k16, save_path=self.save_path,
                                                      RegLoss=self.RegLoss,
                                                      base_optimizer=self.base_optimizer)
            elif self.tta_method == "bitta_si_ema_prior":
                # TODO, L(opt(theta)) + opt(L(theta))
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss, grads \
                    = forward_and_adapt_prior_si_bitta(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                     self.model, self.optimizer, 
                                                     self.margin_e0, 
                                                     self.reset_constant_em, self.ema,
                                                     TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                     k16=self.k16, save_path=self.save_path,
                                                     RegLoss=self.RegLoss,
                                                     l_opt_k=self.l_opt_k,
                                                     history_grads=self.history_grads,
                                                     anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter),
                                                     sam_weight=MyLoss.sam_weight(x=tta_step, total_end=self.total_iter_sam),
                                                     backtrack_degree=self.backtrack_degree,
                                                     base_optimizer=self.base_optimizer,
                                                     k17=self.k17,
                                                     k18=self.k18) 
                # TODO self.history_grads = f(self.history_grads, current_updates)
                # self.history_grads.append(current_updates)
                # print("TODO self.history_grads = f(self.history_grads, current_updates)")
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == "bitta_si_ema_prior_abl":
                # TODO, L(opt(theta)) + opt(L(theta))
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss, grads \
                    = forward_and_adapt_prior_si_bitta_abl(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                         self.model, self.optimizer, 
                                                         self.margin_e0, 
                                                         self.reset_constant_em, self.ema,
                                                         TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                         k16=self.k16, save_path=self.save_path,
                                                         RegLoss=self.RegLoss,
                                                         l_opt_k=self.l_opt_k,
                                                         history_grads=self.history_grads,
                                                         anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter),
                                                         backtrack_degree=self.backtrack_degree,
                                                         base_optimizer=self.base_optimizer) 
                # TODO self.history_grads = f(self.history_grads, current_updates)
                # self.history_grads.append(current_updates)
                # print("TODO self.history_grads = f(self.history_grads, current_updates)")
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == "si_ema_prior":
                # raise NotImplementedError
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss, grads \
                    = forward_and_adapt_prior_si(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                 self.model, self.optimizer, 
                                                 self.margin_e0, 
                                                 self.reset_constant_em, self.ema,
                                                 TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                 k16=self.k16, save_path=self.save_path,
                                                 RegLoss=self.RegLoss,
                                                 l_opt_k=self.l_opt_k,
                                                 history_grads=self.history_grads,
                                                 anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter),
                                                 sam_weight=MyLoss.sam_weight(x=tta_step, total_end=self.total_iter_sam),
                                                 backtrack_degree=self.backtrack_degree,
                                                 base_optimizer=self.base_optimizer,
                                                 disable_bd=self.disable_bd) 
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == "si_ema_prior_TODO":
                # raise NotImplementedError
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss, sim, grads, grads_norm, grads_std \
                    = forward_and_adapt_prior_si_TODO(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                      self.model, self.optimizer, 
                                                      self.margin_e0, 
                                                      self.reset_constant_em, self.ema,
                                                      TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                      k16=self.k16, save_path=self.save_path,
                                                      RegLoss=self.RegLoss,
                                                      l_opt_k=self.l_opt_k,
                                                      history_grads=self.history_grads,
                                                      anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter),
                                                      sam_weight=MyLoss.sam_weight(x=tta_step, total_end=self.total_iter_sam),
                                                      backtrack_degree=self.backtrack_degree,
                                                      base_optimizer=self.base_optimizer,
                                                      disable_bd=self.disable_bd,
                                                      sim_matrix=self.sim_matrix,) 
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            elif self.tta_method == "bitta_si_ema_prior_TODO":
                # TODO, L(opt(theta)) + opt(L(theta))
                update_ema_variables(self.model, self.ema_model, self.ema_param)
                outputs, ema, reset_flag, loss, sim, grads, grads_norm, grads_std \
                    = forward_and_adapt_prior_si_bitta_TODO_New(x, x_aug, tta_step, iter_num, self.save_grad, 
                                                              self.model, self.optimizer, 
                                                              self.margin_e0, 
                                                              self.reset_constant_em, self.ema,
                                                              TCLoss=self.TCLoss, SCLoss=self.SCLoss, 
                                                              k16=self.k16, save_path=self.save_path,
                                                              RegLoss=self.RegLoss,
                                                              l_opt_k=self.l_opt_k,
                                                              history_grads=self.history_grads,
                                                              anneal_weight=MyLoss.anneal_weight(x=tta_step, total_end=self.total_iter),
                                                              sam_weight=MyLoss.sam_weight(x=tta_step, total_end=self.total_iter_sam),
                                                              backtrack_degree=self.backtrack_degree,
                                                              base_optimizer=self.base_optimizer) 
                # TODO self.history_grads = f(self.history_grads, current_updates)
                # self.history_grads.append(current_updates)
                # print("TODO self.history_grads = f(self.history_grads, current_updates)")
                if self.weighted_trend == False:
                    self.merge_grads(current_grads=grads)
                else:
                    self.merge_grads_weighted(current_grads=grads, loss=loss)
            else:
                print(self.tta_method)
                raise NotImplementedError
            if reset_flag:
                self.reset()
            self.ema = ema  # update moving average value of loss
            self.loss_list.append(loss.detach().cpu().numpy())
            if 'TODO' in self.tta_method:
                self.sim_list.append(sim)
                self.grads_norm_list.append(grads_norm)
                self.grads_std_list.append(grads_std)

        return outputs

    def get_loss_list(self):
        return np.mean(self.loss_list)

    def get_loss_sim_list(self):
        return np.mean(self.loss_list), np.mean(self.sim_list)

    def get_loss_sim_grad_list(self):
        # breakpoint()
        return np.mean(self.loss_list), \
            np.mean(np.array(self.sim_list), axis=0), \
            np.mean(np.array(self.grads_norm_list), axis=0), \
            np.mean(np.array(self.grads_std_list), axis=0)
        # return np.mean(self.loss_list), \
        #     np.array(self.sim_list)[1], \
        #     np.mean(np.array(self.grads_norm_list), axis=0), \
        #     np.mean(np.array(self.grads_std_list), axis=0)

    def reset(self):
        if self.model_state is None or self.optimizer_state is None:
            raise Exception("cannot reset without saved model/optimizer state")
        load_model_and_optimizer(self.model, self.optimizer,
                                 self.model_state, self.optimizer_state)
        self.ema = None


@torch.jit.script
def softmax_entropy(x: torch.Tensor) -> torch.Tensor:
    """Entropy of softmax distribution from logits."""
    return -(x.softmax(1) * x.log_softmax(1)).sum(1)

################################### TODO ############################################

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_TODO(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                 history_grads, sim_matrix, anneal_weight):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    # adapt
    # SAR: filtering reliable samples/gradients for further adaptation; first time forward
    # entropys = softmax_entropy(HR_C_pr)
    # filter_ids_1 = torch.where(entropys < margin)
    # entropys = entropys[filter_ids_1]
    # loss = entropys.mean(0)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # print(f"==> in TTA_Prior, loss={loss}")
    # -k9 0.001 -k10 0.01

    loss.backward()

    if save_grad:
        with torch.no_grad():
            # grads_first = []
            grads = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    # grads_first.append(deepcopy(param.grad.clone()))
                    grads.append(deepcopy(param.grad.clone()))
        
    # optimizer.step()
    _, grads_raw = optimizer.step_no_update()
    # _, _, grads = optimizer.step_with_grad(grads=grads_raw)
    _, _, grads = optimizer.step_with_grad_nograd(grads=grads_raw)
    
    # idx_list = [3, 6, 9, 12, 15, 18, 24, 27, 
    #             30, 33, 39, 42, 45, 48, 54, 57,
    #             60, 61]
    idx_list = [i for i in range(62)]
    # sim = 0.0
    sim = [0.0 for _ in idx_list]
    if history_grads != None: # False for si_debug_4, ablation
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # similarity, _ = calculate_projection_similarity_TODO(history_grads, grads, matrix=sim_matrix)
        # sim = torch.mean(similarity)
        # sim = torch.mean(torch.stack(similarity[:62]))
        anneal_sim_weight = 1.0
        if type(similarity[0]) == np.float64 or type(similarity[0]) == float: 
            sim = [anneal_sim_weight * similarity[idx] for idx in idx_list]
        else:
            sim = [anneal_sim_weight * torch.squeeze(similarity[idx]).detach().cpu().numpy() for idx in idx_list] 

    grads_norm = []
    grads_std = []
    for idx in idx_list:
        grads_norm.append(grads[idx].norm().detach().cpu().numpy())    
        grads_std.append(grads[idx].std().detach().cpu().numpy())    

    if save_grad:
        with torch.no_grad():
            if not os.path.exists(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}'):
                os.mkdir(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}')
            for i, gradient in enumerate(grads):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/{i}.npy', gradient.cpu().numpy())

    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, loss, sim, grads, grads_norm, grads_std

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_bitta_TODO(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                     history_grads, sim_matrix, anneal_weight):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at  TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0

    # adapt
    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_first = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_first.append(deepcopy(param.grad.clone()))
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_second = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_second.append(deepcopy(param.grad.clone()))
        
    # optimizer.second_step(zero_grad=True)
    _, grads_raw = optimizer.before_second_step()
    _, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)
    # idx_list = [3, 6, 9, 12, 15, 18, 24, 27, 
    #             30, 33, 39, 42, 45, 48, 54, 57,
    #             60, 61]
    idx_list = [i for i in range(62)]
    # sim = 0.0
    sim = [0.0 for _ in idx_list]
    if history_grads != None: # False for si_debug_4, ablation
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # similarity, _ = calculate_projection_similarity_TODO(history_grads, grads, matrix=sim_matrix)
        # sim = torch.mean(similarity)
        # sim = torch.mean(torch.stack(similarity[:62]))
        anneal_sim_weight = 1.0
        if type(similarity[0]) == np.float64 or type(similarity[0]) == float: 
            sim = [anneal_sim_weight * similarity[idx] for idx in idx_list]
        else:
            sim = [anneal_sim_weight * torch.squeeze(similarity[idx]).detach().cpu().numpy() for idx in idx_list] 
        # print(anneal_weight)
        # print(sim)
    # TODO, extract grad. from middle and output layers
    grads_norm = []
    grads_std = []
    for idx in idx_list:
        grads_norm.append(grads[idx].norm().detach().cpu().numpy())    
        grads_std.append(grads[idx].std().detach().cpu().numpy())    

    if save_grad:
        with torch.no_grad():
            if not os.path.exists(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}'):
                os.mkdir(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}')

            for i, gradient in enumerate(grads_first):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/first_{i}.npy', gradient.cpu().numpy())
            for i, gradient in enumerate(grads_second):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/second_{i}.npy', gradient.cpu().numpy())

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss, sim, grads, grads_norm, grads_std

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_GT_bitta_TODO(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                  history_grads, args, sim_matrix, anneal_weight):
    # loss_func_NP, loss_func_L1, args, \
    #      loss_func_NEST_CM, loss_func_NEST_DM, loss_func_NEST_TA = GT_input
    if torch.cuda.is_available(): device = 'cuda:' + args.GPU
    else: device = 'cpu'
    
    frames_num = args.frames_num    
    loss_func_NP = MyLoss.P_loss3().to(device)
    loss_func_L1 = nn.L1Loss().to(device)
    loss_func_cov = MyLoss.Cov_loss().to(device)
    loss_func_dig = MyLoss.Cov_Dig_loss2().to(device)
    loss_func_con = MyLoss.contrast_loss().to(device)
    loss_func_SP = MyLoss.SP_loss(device, clip_length=frames_num).to(device)
    loss_func_smooth = MyLoss.Smooth_loss3(device, Num_ref=8).to(device)

    x, bvp, HR_rel = x 
    x_aug, bvp_aug, HR_rel_aug = x_aug
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    source_name_0 = 'VIPL'

    src_loss_0 = MyLoss.get_loss(bvp_pre, HR_pr, bvp, HR_rel, source_name_0, \
                                    loss_func_NP, loss_func_L1, args, iter_num)

    src_loss_aug_0 = MyLoss.get_loss(bvp_pre_aug, HR_pr_aug, bvp_aug, HR_rel_aug, source_name_0, \
                                    loss_func_NP, loss_func_L1, args, iter_num)

    HR_rels = HR_rel # torch.cat((HR_rel0, HR_rel1, HR_rel2, HR_rel3), dim=0)
    HR_rel_augs = HR_rel_aug # torch.cat((HR_rel_aug0, HR_rel_aug1, HR_rel_aug2, HR_rel_aug3), dim=0)
    loss_Cov = loss_func_dig(torch.cat((av, av_aug), dim=0))
    loss_con = loss_func_con(av, av_aug)
    loss_smooth = loss_func_smooth(torch.cat((av, av_aug), dim=0), torch.cat((HR_rels, HR_rel_augs), dim=0))
    
    k = 2.0 / (1.0 + np.exp(-10.0 * tta_step / args.max_iter)) - 1.0
    tclscl_loss = src_loss_0 + src_loss_aug_0 + \
        0.1 * k* loss_smooth + 0.001*k* loss_Cov + 0.01*k*loss_con \
        # + k * (tc_loss * args.k9 + sc_loss * args.k10) 

        # 0.1 * k * loss_TA + 0.001 * k * loss_CM + 0.01 * k * loss_DM

    # loss = (src_loss_0 + src_loss_1 + src_loss_2 + src_loss_3) \
    #         + (src_loss_aug_0 + src_loss_aug_1 + src_loss_aug_2 + src_loss_aug_3) \
    #         + 0.1 * k * loss_TA + 0.001 * k * loss_CM + 0.01 * k * loss_DM

    # loss = src_loss_0 + src_loss_aug_0 + 0.1 * k * loss_TA + 0.001 * k * loss_CM + 0.01 * k * loss_DM

    # # Prior
    # tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    # sc_loss_0 = SCLoss(em_all[0])
    # sc_loss_1 = SCLoss(em_all[1])
    # sc_loss_2 = SCLoss(em_all[2])
    # sc_loss_3 = SCLoss(em_all[3])
    # sc_loss_aug_0 = SCLoss(em_aug_all[0])
    # sc_loss_aug_1 = SCLoss(em_aug_all[1])
    # sc_loss_aug_2 = SCLoss(em_aug_all[2])
    # sc_loss_aug_3 = SCLoss(em_aug_all[3])
    # sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    # tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at  TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0

    # adapt
    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_first = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_first.append(deepcopy(param.grad.clone()))
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    # bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    # bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # # Prior
    # tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    # sc_loss_0 = SCLoss(em_all[0])
    # sc_loss_1 = SCLoss(em_all[1])
    # sc_loss_2 = SCLoss(em_all[2])
    # sc_loss_3 = SCLoss(em_all[3])
    # sc_loss_aug_0 = SCLoss(em_aug_all[0])
    # sc_loss_aug_1 = SCLoss(em_aug_all[1])
    # sc_loss_aug_2 = SCLoss(em_aug_all[2])
    # sc_loss_aug_3 = SCLoss(em_aug_all[3])
    # sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    # tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    source_name_0 = 'VIPL'

    src_loss_0 = MyLoss.get_loss(bvp_pre, HR_pr, bvp, HR_rel, source_name_0, \
                                    loss_func_NP, loss_func_L1, args, iter_num)

    src_loss_aug_0 = MyLoss.get_loss(bvp_pre_aug, HR_pr_aug, bvp_aug, HR_rel_aug, source_name_0, \
                                    loss_func_NP, loss_func_L1, args, iter_num)

    HR_rels = HR_rel # torch.cat((HR_rel0, HR_rel1, HR_rel2, HR_rel3), dim=0)
    HR_rel_augs = HR_rel_aug # torch.cat((HR_rel_aug0, HR_rel_aug1, HR_rel_aug2, HR_rel_aug3), dim=0)
    loss_Cov = loss_func_dig(torch.cat((av, av_aug), dim=0))
    loss_con = loss_func_con(av, av_aug)
    loss_smooth = loss_func_smooth(torch.cat((av, av_aug), dim=0), torch.cat((HR_rels, HR_rel_augs), dim=0))

    k = 2.0 / (1.0 + np.exp(-10.0 * tta_step / args.max_iter)) - 1.0
    tclscl_loss = src_loss_0 + src_loss_aug_0 + \
        0.1 * k* loss_smooth + 0.001*k* loss_Cov + 0.01*k*loss_con

    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_second = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_second.append(deepcopy(param.grad.clone()))

    # optimizer.second_step(zero_grad=True)
    _, grads_raw = optimizer.before_second_step()
    _, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)
    # idx_list = [3, 6, 9, 12, 15, 18, 24, 27, 
    #             30, 33, 39, 42, 45, 48, 54, 57,
    #             60, 61]
    idx_list = [i for i in range(62)]
    sim = [0.0 for _ in idx_list]
    if history_grads != None: # False for si_debug_4, ablation
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # similarity, _ = calculate_projection_similarity_TODO(history_grads, grads, matrix=sim_matrix)
        # sim = torch.mean(similarity)
        # sim = torch.mean(torch.stack(similarity[:62]))
        # similarity = torch.squeeze(similarity) # *** TypeError: squeeze(): argument 'input' (position 1) must be Tensor, not list
        # breakpoint()
        anneal_sim_weight = 1.0
        if type(similarity[0]) == np.float64 or type(similarity[0]) == float: 
            sim = [anneal_sim_weight * similarity[idx] for idx in idx_list]
        else:
            sim = [anneal_sim_weight * torch.squeeze(similarity[idx]).detach().cpu().numpy() for idx in idx_list] 
        # sim = similarity[idx_list].detach().cpu().numpy()
    grads_norm = []
    grads_std = []
    for idx in idx_list:
        grads_norm.append(grads[idx].norm().detach().cpu().numpy())    
        grads_std.append(grads[idx].std().detach().cpu().numpy())    

    if save_grad:
        with torch.no_grad():
            if not os.path.exists(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}'):
                os.mkdir(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}')

            for i, gradient in enumerate(grads_first):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/first_{i}.npy', gradient.cpu().numpy())
            for i, gradient in enumerate(grads_second):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/second_{i}.npy', gradient.cpu().numpy())

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss, sim, grads, grads_norm, grads_std


####################################### TODO ########################################

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    # adapt
    # SAR: filtering reliable samples/gradients for further adaptation; first time forward
    # entropys = softmax_entropy(HR_C_pr)
    # filter_ids_1 = torch.where(entropys < margin)
    # entropys = entropys[filter_ids_1]
    # loss = entropys.mean(0)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # print(f"==> in TTA_Prior, loss={loss}")
    # -k9 0.001 -k10 0.01

    loss.backward()

    if save_grad:
        with torch.no_grad():
            # grads_first = []
            grads = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    # grads_first.append(deepcopy(param.grad.clone()))
                    grads.append(deepcopy(param.grad.clone()))
        
    optimizer.step()

    if save_grad:
        with torch.no_grad():
            if not os.path.exists(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}'):
                os.mkdir(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}')
            for i, gradient in enumerate(grads):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/{i}.npy', gradient.cpu().numpy())

    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, loss

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_bitta(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at  TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0

    # adapt
    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_first = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_first.append(deepcopy(param.grad.clone()))
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_second = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_second.append(deepcopy(param.grad.clone()))
        
    optimizer.second_step(zero_grad=True)

    if save_grad:
        with torch.no_grad():
            if not os.path.exists(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}'):
                os.mkdir(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}')

            for i, gradient in enumerate(grads_first):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/first_{i}.npy', gradient.cpu().numpy())
            for i, gradient in enumerate(grads_second):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/second_{i}.npy', gradient.cpu().numpy())

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss

######################################### ABLATION ################################################

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_bitta_abl_2(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                      RegLoss, base_optimizer):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # bling he
    # _, em_all_raw, _, HR_pr, _, _ = model(x)
    # _, em_aug_all_raw, _, HR_pr_aug, _, _ = model(x_aug)
    # em_all = []
    # for em_all_info in em_all_raw: em_all.append(em_all_info.detach())
    # em_aug_all = []
    # for em_aug_all_info in em_aug_all_raw: em_aug_all.append(em_aug_all_info.detach())
    # HR_pr = HR_pr.detach()
    # HR_pr_aug = HR_pr_aug.detach()
    # # bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = \
    # #     bvp_pre_all.detach(), em_all.detach(), bvp_pre.detach(), HR_pr.detach(), HR_C_pr.detach(), av.detach()
    # # bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = \
    # #     bvp_pre_aug_all.detach(), em_aug_all.detach(), bvp_pre_aug.detach(), HR_pr_aug.detach(), HR_C_pr_aug.detach(), av_aug.detach()

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at  TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0

    # adapt
    # tclscl_loss.backward(retain_graph=True) # cc98
    tclscl_loss.backward()

    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    # tclscl_loss.backward()

    # haodongli @ 2023年11月9日10点12分, for strict ablation, but do not work
    # with torch.no_grad():
    tclscl_loss.backward()
    # optimizer.second_step(zero_grad=True)

    # haodongli, using another optimizer here, it works!!!!!!
    # updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads_raw = base_optimizer.step_no_update(zero_grad=True)
    
    # print(f"==> {updates[0]}")
    # breakpoint()

    # haodongli, to erase history grad. info., but do not work
    # for param in model.parameters():
    #     param.grad = None

    # re-calculate tclscl
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16

    # new penalty: penalize all layers
    tclscl_loss_re = tclscl_loss_re + 0.0 * RegLoss(updates)

    assert tclscl_loss.item() == tclscl_loss_re.item(), f"tclscl_loss:{tclscl_loss.item()} != tclscl_loss_re:{tclscl_loss_re.item()}"
    tclscl_loss_re.backward()

    updates, grads_raw = optimizer.before_second_step(zero_grad=True)

    updates, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_bitta_abl_1(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at  TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0

    # adapt
    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_first = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_first.append(deepcopy(param.grad.clone()))
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    tclscl_loss.backward()

    if save_grad:
        with torch.no_grad():
            grads_second = []
            # Save the gradients after every batch update
            for param in model.parameters():
                if param.grad is not None:
                    grads_second.append(deepcopy(param.grad.clone()))
        
    # optimizer.second_step(zero_grad=True)
    updates, grads_raw = optimizer.before_second_step()
    updates, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)

    if save_grad:
        with torch.no_grad():
            if not os.path.exists(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}'):
                os.mkdir(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}')

            for i, gradient in enumerate(grads_first):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/first_{i}.npy', gradient.cpu().numpy())
            for i, gradient in enumerate(grads_second):
                np.save(f'./' + save_path + f'/Result_Gradient/iter_{iter_num}/tta_{tta_step}/second_{i}.npy', gradient.cpu().numpy())

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss

######################################### ABLATION ##############################################

#################################### TODO BACKTRACKING #########################################

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_si_TODO(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                    RegLoss, l_opt_k, history_grads, anneal_weight, sam_weight, backtrack_degree, base_optimizer, disable_bd, sim_matrix):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0, None
        # ema, reset_flag, tclscl_loss, grads

    # adapt
    tclscl_loss.backward()
    # updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads_raw_first = base_optimizer.step_no_update(zero_grad=True)

    # re-calculate tclscl
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16 * sam_weight

    # new penalty: penalize all layers
    tclscl_loss_re = tclscl_loss_re + l_opt_k * RegLoss(updates)
    if l_opt_k == 0 and sam_weight == 1.0: assert tclscl_loss.item() == tclscl_loss_re.item(), f"tclscl_loss:{tclscl_loss.item()} != tclscl_loss_re:{tclscl_loss_re.item()}"
    tclscl_loss_re.backward()

    updates, grads_raw = optimizer.step_no_update()

    if history_grads != None and disable_bd == False:
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # print("TODO weight = f(history_grads, grads)")
        grads_new = sim_to_grads(similarity, projection, backtrack_degree=backtrack_degree)
        grads_out = []
        for (i, grad_raw) in enumerate(grads_raw):
            if grad_raw == None: 
                grads_out.append(None)
                continue
            grads_out.append(grad_raw*(1-anneal_weight) + grads_new[i]*anneal_weight)
        # _, updates, grads = optimizer.step_with_grad(grads=grads_out)
        _, updates, grads = optimizer.step_with_grad_nograd(grads=grads_out)
    else:
        # updates, grads = optimizer.step_with_grad(grads=grads_raw)
        _, updates, grads = optimizer.step_with_grad_nograd(grads=grads_raw)


    # idx_list = [3, 6, 9, 12, 15, 18, 24, 27, 
    #             30, 33, 39, 42, 45, 48, 54, 57,
    #             60, 61]
    idx_list = [i for i in range(62)]
    sim = [0.0 for _ in idx_list]
    if history_grads != None: # False for si_debug_4, ablation
        # similarity, _ = calculate_projection_similarity_TODO(history_grads, grads, matrix=sim_matrix)
        anneal_sim_weight = 1.0
        if type(similarity[0]) == np.float64 or type(similarity[0]) == float: 
            sim = [anneal_sim_weight * similarity[idx] for idx in idx_list]
        else:
            sim = [anneal_sim_weight * torch.squeeze(similarity[idx]).detach().cpu().numpy() for idx in idx_list] 
    grads_norm = []
    grads_std = []
    for idx in idx_list:
        grads_norm.append(grads[idx].norm().detach().cpu().numpy())    
        grads_std.append(grads[idx].std().detach().cpu().numpy())  


    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss, sim, grads, grads_norm, grads_std

# @torch.enable_grad()  # ensure grads in possible no grad context for testing
# def forward_and_adapt_prior_si_bitta_TODO_New(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
#                                    RegLoss, l_opt_k, history_grads, anneal_weight, backtrack_degree, base_optimizer):

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_si_bitta_TODO_New(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                   RegLoss, l_opt_k, history_grads, anneal_weight, sam_weight, backtrack_degree, base_optimizer):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0, None
        # ema, reset_flag, tclscl_loss, grads

    # adapt
    tclscl_loss.backward()
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    # tclscl_loss.backward(retain_graph=True)
    # # RuntimeError: Only Tensors created explicitly by the user (graph leaves) support the deepcopy protocol at the moment
    # # tclscl_loss_copy = deepcopy(tclscl_loss)

    # # optimizer.second_step(weights=opt_l_weights, zero_grad=True)
    
    # updates, grads = optimizer.before_second_step()    
    # # new penalty: penalize all layers
    # penalty_term = None
    # for update in updates:
    #     if update == None: continue
    #     if penalty_term == None: penalty_term = torch.norm(update, p=1)
    #     else: penalty_term = penalty_term + torch.norm(update, p=1)
    # tclscl_loss = tclscl_loss + l_opt_k*penalty_term
    # tclscl_loss.backward()

    # updates, grads_raw = optimizer.before_second_step()

    # adapt
    tclscl_loss.backward()
    # updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads_raw_first = base_optimizer.step_no_update(zero_grad=True)

    # re-calculate tclscl
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    # tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16
    # haodongli 2023年11月23日00点02分
    tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16 * sam_weight

    # new penalty: penalize all layers
    tclscl_loss_re = tclscl_loss_re + l_opt_k * RegLoss(updates)
    if l_opt_k == 0: assert tclscl_loss.item() == tclscl_loss_re.item(), f"tclscl_loss:{tclscl_loss.item()} != tclscl_loss_re:{tclscl_loss_re.item()}"
    tclscl_loss_re.backward()

    updates, grads_raw = optimizer.before_second_step(zero_grad=True)

    # haodongli @ 2023年11月22日20点15分
    # grads_raw_new = []
    # for grad in grads_raw:
    #     if grad != None: 
    #         grads_raw_new.append(grad * sam_weight)
    #     else:
    #         grads_raw_new.append(grad)
    # grads_raw = grads_raw_new

    # TODO weight = f(history_grads, grads)
    # if False: # history_grads != None: # TTA_Reg_0.1_BT_0
    if history_grads != None: # False for si_debug_4, ablation
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # print("TODO weight = f(history_grads, grads)")
        # haodongli test layer specific or full 2023年11月11日00点53分 !!!!!!!!!
        # grads_new = sim_to_grads_test(similarity, projection, backtrack_degree=backtrack_degree)
        
        # haodongli @ 2023年11月15日16点55分
        # grads_new = sim_to_grads(similarity, grads_raw, backtrack_degree=backtrack_degree)
        # grads_new = sim_to_grads(similarity, projection, backtrack_degree=backtrack_degree)
        grads_new = sim_to_grads_new(similarity, projection, grads_raw, backtrack_degree=backtrack_degree)
        
        
        grads_out = []
        for (i, grad_raw) in enumerate(grads_raw):
            if grad_raw == None: 
                grads_out.append(None)
                continue
            grads_out.append(grad_raw*(1-anneal_weight) + grads_new[i]*anneal_weight)
        updates, grads = optimizer.true_second_step_with_grad(grads=grads_out, zero_grad=True)
    else:
        # weights = torch.tensor([1.0 for _ in grads], dtype=torch.float32, device=grads[0].device)
        # updates, grads = optimizer.true_second_step(weights=weights, zero_grad=True)
        updates, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)

    # weight = weight_start * (1 - anneal_weight) + anneal_weight * weight

    # L(opt(theta)) with l_opt_weights
    # history_grads, anneal_weight
    # output layers: 60,61;
    # penalty_term = l_opt_weights[60] * torch.norm(updates[60], p=1) \
    #     + l_opt_weights[61] * torch.norm(updates[61], p=1)

    # updates, grads = optimizer.true_second_step(weights=weights, zero_grad=True)
    # updates, grads = optimizer.true_second_step_with_grad(weights=weights, grads=None, zero_grad=True)

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    idx_list = [i for i in range(62)]
    sim = [0.0 for _ in idx_list]
    if history_grads != None: # False for si_debug_4, ablation
        # similarity, _ = calculate_projection_similarity_TODO(history_grads, grads, matrix=sim_matrix)
        anneal_sim_weight = 1.0
        if type(similarity[0]) == np.float64 or type(similarity[0]) == float: 
            sim = [anneal_sim_weight * similarity[idx] for idx in idx_list]
        else:
            sim = [anneal_sim_weight * torch.squeeze(similarity[idx]).detach().cpu().numpy() for idx in idx_list] 
    grads_norm = []
    grads_std = []
    for idx in idx_list:
        grads_norm.append(grads[idx].norm().detach().cpu().numpy())    
        grads_std.append(grads[idx].std().detach().cpu().numpy())  

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)

    return outputs, ema, reset_flag, tclscl_loss, sim, grads, grads_norm, grads_std

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_si_bitta_TODO(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                        RegLoss, l_opt_k, history_grads, anneal_weight, backtrack_degree, base_optimizer, sim_matrix):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0, None
        # ema, reset_flag, tclscl_loss, grads

    # adapt
    tclscl_loss.backward()
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    # tclscl_loss.backward(retain_graph=True)
    # # RuntimeError: Only Tensors created explicitly by the user (graph leaves) support the deepcopy protocol at the moment
    # # tclscl_loss_copy = deepcopy(tclscl_loss)

    # adapt
    tclscl_loss.backward()
    # updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads_raw_first = base_optimizer.step_no_update(zero_grad=True)

    # re-calculate tclscl
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16

    # new penalty: penalize all layers
    tclscl_loss_re = tclscl_loss_re + l_opt_k * RegLoss(updates)
    if l_opt_k == 0: assert tclscl_loss.item() == tclscl_loss_re.item(), f"tclscl_loss:{tclscl_loss.item()} != tclscl_loss_re:{tclscl_loss_re.item()}"
    tclscl_loss_re.backward()

    updates, grads_raw = optimizer.before_second_step(zero_grad=True)

    # TODO weight = f(history_grads, grads)
    # if False: # history_grads != None: # TTA_Reg_0.1_BT_0
    if history_grads != None: # False for si_debug_4, ablation
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # print("TODO weight = f(history_grads, grads)")
        grads_new = sim_to_grads(similarity, projection, backtrack_degree=backtrack_degree)
        # updates, grads = optimizer.true_second_step_with_grad(weights=weights, grads=grads, zero_grad=True)
        grads_out = []
        for (i, grad_raw) in enumerate(grads_raw):
            if grad_raw == None: 
                grads_out.append(None)
                continue
            grads_out.append(grad_raw*(1-anneal_weight) + grads_new[i]*anneal_weight)
        updates, grads = optimizer.true_second_step_with_grad(grads=grads_out, zero_grad=True)
    else:
        # weights = torch.tensor([1.0 for _ in grads], dtype=torch.float32, device=grads[0].device)
        # updates, grads = optimizer.true_second_step(weights=weights, zero_grad=True)
        updates, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)

    # idx_list = [3, 6, 9, 12, 15, 18, 24, 27, 
    #             30, 33, 39, 42, 45, 48, 54, 57,
    #             60, 61]
    idx_list = [i for i in range(62)]
    sim = [0.0 for _ in idx_list]
    if history_grads != None: # False for si_debug_4, ablation
        # similarity, _ = calculate_projection_similarity_TODO(history_grads, grads, matrix=sim_matrix)
        anneal_sim_weight = 1.0
        if type(similarity[0]) == np.float64 or type(similarity[0]) == float: 
            sim = [anneal_sim_weight * similarity[idx] for idx in idx_list]
        else:
            sim = [anneal_sim_weight * torch.squeeze(similarity[idx]).detach().cpu().numpy() for idx in idx_list] 
    grads_norm = []
    grads_std = []
    for idx in idx_list:
        grads_norm.append(grads[idx].norm().detach().cpu().numpy())    
        grads_std.append(grads[idx].std().detach().cpu().numpy())  

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss, sim, grads, grads_norm, grads_std

#################################### TODO BACKTRACKING #########################################

def projection_similarity(history_grad, current_grad, matrix='cosine', eps=1e-8):
    history_grad = history_grad.view(-1).unsqueeze(0)
    current_grad = current_grad.view(-1).unsqueeze(0)
    a_norm = history_grad / (history_grad.norm(dim=0) + eps) # normalize a
    proj = a_norm * torch.dot(a_norm.view(-1), current_grad.view(-1))
    if matrix == 'cosine':
        sim = cosine_similarity(history_grad, proj, dim=1, eps=1e-8)
    else:
        print(f"==> similarity_matrix: {matrix}")
        raise NotImplementedError
    return proj, sim

def projection_similarity_TODO(history_grad, current_grad, matrix='cosine', eps=1e-16):
    a_norm = history_grad / (history_grad.norm() + eps) # normalize a
    b_norm = current_grad / (current_grad.norm() + eps)
    if matrix == 'cosine':
        sim = cosine_similarity(a_norm.view(-1).unsqueeze(0), b_norm.view(-1).unsqueeze(0), dim=1, eps=1e-8)
    elif matrix == 'pearsonr':
        if len(history_grad.view(-1).cpu().numpy()) < 2: sim = 0.0
        else: sim, _ = pearsonr(a_norm.view(-1).cpu().numpy(), b_norm.view(-1).cpu().numpy())
    else:
        print(f"==> similarity_matrix: {matrix}")
        raise NotImplementedError
    return None, sim

def projection_similarity_keepdim(history_grad, current_grad, matrix='cosine', eps=1e-16):
    # history_grad = history_grad.view(-1).unsqueeze(0)
    # current_grad = current_grad.view(-1).unsqueeze(0)
    # a_norm = history_grad / (history_grad.norm(dim=0) + eps) # normalize a
    a_norm = history_grad / (history_grad.norm() + eps) # normalize a
    b_norm = current_grad / (current_grad.norm() + eps)
    # proj = a_norm * torch.dot(a_norm, current_grad)
    # proj = a_norm * torch.dot(a_norm.view(-1), current_grad.view(-1))
    if len(history_grad.shape) == 4:
        # proj = torch.einsum('ijkl,ijkl->ijkl', a_norm, b_norm) * current_grad.norm() # * history_grad.norm()
        proj_temp = torch.einsum('ijkl,ijkl->ijkl', a_norm, b_norm)
        # proj_temp_ref = torch.einsum('ijkl,ijkl->ijkl', b_norm, b_norm)
        # proj = proj_temp * (1.0/proj_temp.norm()) * current_grad.norm()
        proj = proj_temp * current_grad.norm()
    elif len(history_grad.shape) == 3:
        # proj = torch.einsum('ijk,ijk->ijk', a_norm, b_norm) * current_grad.norm() # * history_grad.norm()
        proj_temp = torch.einsum('ijk,ijk->ijk', a_norm, b_norm)
        # proj_temp_ref = torch.einsum('ijk,ijk->ijk', b_norm, b_norm)
        # proj = proj_temp * (1.0/proj_temp.norm()) * current_grad.norm()
        proj = proj_temp * current_grad.norm()
    elif len(history_grad.shape) == 2:
        # proj = torch.einsum('ij,ij->ij', a_norm, b_norm) * current_grad.norm() # * history_grad.norm()
        proj_temp = torch.einsum('ij,ij->ij', a_norm, b_norm)
        # proj_temp_ref = torch.einsum('ij,ij->ij', b_norm, b_norm)
        # proj = proj_temp * (1.0/proj_temp.norm()) * current_grad.norm()
        proj = proj_temp * current_grad.norm()
    elif len(history_grad.shape) == 1:
        # proj = torch.einsum('i,i->i', a_norm, b_norm) * current_grad.norm() # * history_grad.norm()
        proj_temp = torch.einsum('i,i->i', a_norm, b_norm)
        # proj_temp_ref = torch.einsum('i,i->i', b_norm, b_norm)
        # proj = proj_temp * (1.0/proj_temp.norm()) * current_grad.norm()
        proj = proj_temp * current_grad.norm()
        # proj = torch.dot(a_norm, b_norm) * current_grad.norm()
    # elif len(history_grad.shape) == 0:
    #     print(history_grad.shape)
    #     breakpoint()
    else:
        print(history_grad.shape)
        raise NotImplementedError
    if matrix == 'cosine':
        # sim = cosine_similarity(history_grad, proj, dim=1, eps=1e-8)
        # sim = cosine_similarity(history_grad.view(-1).unsqueeze(0), 
        #                         current_grad.view(-1).unsqueeze(0), dim=1, eps=1e-8)
        sim = cosine_similarity(history_grad.view(-1).unsqueeze(0), 
                                proj.view(-1).unsqueeze(0), dim=1, eps=1e-8)
    elif matrix == 'pearsonr':
        if len(history_grad.view(-1).cpu().numpy()) < 2: sim = 0.0
        else: sim, _ = pearsonr(history_grad.view(-1).cpu().numpy(), 
                                proj.view(-1).cpu().numpy())
    else:
        print(f"==> similarity_matrix: {matrix}")
        raise NotImplementedError
    return proj, sim

def calculate_projection_similarity_TODO(history_grads, current_grads, matrix='cosine', eps=1e-16):
    similarity = []
    projection = []
    size = len(current_grads)
    for i in range(size):
        if history_grads[i] == None:
            similarity.append(None)
            projection.append(None)
            continue
        proj, sim = projection_similarity_TODO(history_grads[i], current_grads[i], matrix=matrix, eps=eps)
        projection.append(proj)
        similarity.append(sim)
    return similarity, projection

def calculate_projection_similarity(history_grads, current_grads, matrix='cosine', eps=1e-16):
    similarity = []
    projection = []
    size = len(current_grads)
    for i in range(size):
        if history_grads[i] == None:
            similarity.append(None)
            projection.append(None)
            continue
        proj, sim = projection_similarity_keepdim(history_grads[i], current_grads[i], matrix=matrix, eps=eps)
        projection.append(proj)
        similarity.append(sim)
        # history_grad = history_grads[i].view(-1).unsqueeze(0)
        # current_grad = current_grads[i].view(-1).unsqueeze(0)
        # a_norm = history_grad / history_grad.norm(dim=0)  # normalize a
        # proj = a_norm * torch.dot(a_norm.view(-1), current_grad.view(-1))
        # projection.append(proj)
        # if matrix == 'cosine':
        #     similarity.append(cosine_similarity(history_grad, proj, dim=1, eps=1e-8))
        #     # similarity.append(cosine_similarity(history_grad.unsqueeze(0), 
        #     #                                     current_grad.unsqueeze(0), dim=1, eps=1e-8))
        # else:
        #     print(f"==> similarity_matrix: {matrix}")
        #     raise NotImplementedError
    return similarity, projection

def sim_to_grads(similarity, projection, backtrack_degree=1.0):
    grads = []
    for idx, sim in enumerate(similarity):
        if sim == None: grads.append(None)
        elif sim < 0: 
            grads.append(projection[idx]*backtrack_degree)
        else: grads.append(projection[idx])
    return grads

def sim_to_grads_new(similarity, projection, grads_raw, backtrack_degree=1.0):
    grads = []
    for idx, sim in enumerate(similarity):
        if sim == None: grads.append(None)
        elif sim < 0: 
            grads.append(projection[idx]*backtrack_degree)
        else: grads.append(grads_raw[idx])
    return grads


def sim_to_grads_test(similarity, projection, backtrack_degree=1.0):
    # breakpoint()
    sim_new = [sim.detach().cpu().numpy() for sim in similarity[:62]]
    if np.mean(sim_new) < 0: 
        grads = []
        for idx, sim in enumerate(similarity):
            if sim == None: grads.append(None)
            else: grads.append(projection[idx]*backtrack_degree)
        return grads
    else: 
        return projection
    grads = []
    for idx, sim in enumerate(similarity):
        if sim == None: grads.append(None)
        elif sim < 0: 
            grads.append(projection[idx]*backtrack_degree)
        else: grads.append(projection[idx])
    return grads

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_si_bitta(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                   RegLoss, l_opt_k, history_grads, anneal_weight, sam_weight, backtrack_degree, base_optimizer, k17, k18):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*k17 + tc_loss*k18) * k16 # sc_loss*0.001 + tc_loss*0.01

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0, None
        # ema, reset_flag, tclscl_loss, grads

    # adapt
    tclscl_loss.backward()
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*k17 + tc_loss*k18) * k16 # sc_loss*0.001 + tc_loss*0.01
    # # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    # tclscl_loss.backward(retain_graph=True)
    # # RuntimeError: Only Tensors created explicitly by the user (graph leaves) support the deepcopy protocol at the moment
    # # tclscl_loss_copy = deepcopy(tclscl_loss)

    # # optimizer.second_step(weights=opt_l_weights, zero_grad=True)
    
    # updates, grads = optimizer.before_second_step()    
    # # new penalty: penalize all layers
    # penalty_term = None
    # for update in updates:
    #     if update == None: continue
    #     if penalty_term == None: penalty_term = torch.norm(update, p=1)
    #     else: penalty_term = penalty_term + torch.norm(update, p=1)
    # tclscl_loss = tclscl_loss + l_opt_k*penalty_term
    # tclscl_loss.backward()

    # updates, grads_raw = optimizer.before_second_step()

    # adapt
    tclscl_loss.backward()
    # updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads_raw_first = base_optimizer.step_no_update(zero_grad=True)

    # re-calculate tclscl
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    # tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16
    # haodongli 2023年11月23日00点02分
    tclscl_loss_re = (sc_loss*k17 + tc_loss*k18) * k16 * sam_weight

    # new penalty: penalize all layers
    tclscl_loss_re = tclscl_loss_re + l_opt_k * RegLoss(updates)
    if l_opt_k == 0 and  sam_weight == 1.0: assert tclscl_loss.item() == tclscl_loss_re.item(), f"tclscl_loss:{tclscl_loss.item()} != tclscl_loss_re:{tclscl_loss_re.item()}"
    tclscl_loss_re.backward()

    updates, grads_raw = optimizer.before_second_step(zero_grad=True)

    # haodongli @ 2023年11月22日20点15分
    # grads_raw_new = []
    # for grad in grads_raw:
    #     if grad != None: 
    #         grads_raw_new.append(grad * sam_weight)
    #     else:
    #         grads_raw_new.append(grad)
    # grads_raw = grads_raw_new

    # TODO weight = f(history_grads, grads)
    # if False: # history_grads != None: # TTA_Reg_0.1_BT_0
    if history_grads != None: # False for si_debug_4, ablation
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # print("TODO weight = f(history_grads, grads)")
        # haodongli test layer specific or full 2023年11月11日00点53分 !!!!!!!!!
        # grads_new = sim_to_grads_test(similarity, projection, backtrack_degree=backtrack_degree)
        
        # haodongli @ 2023年11月15日16点55分
        # grads_new = sim_to_grads(similarity, grads_raw, backtrack_degree=backtrack_degree)
        # grads_new = sim_to_grads(similarity, projection, backtrack_degree=backtrack_degree)
        grads_new = sim_to_grads_new(similarity, projection, grads_raw, backtrack_degree=backtrack_degree)
        
        
        grads_out = []
        for (i, grad_raw) in enumerate(grads_raw):
            if grad_raw == None: 
                grads_out.append(None)
                continue
            grads_out.append(grad_raw*(1-anneal_weight) + grads_new[i]*anneal_weight)
        updates, grads = optimizer.true_second_step_with_grad(grads=grads_out, zero_grad=True)
    else:
        # weights = torch.tensor([1.0 for _ in grads], dtype=torch.float32, device=grads[0].device)
        # updates, grads = optimizer.true_second_step(weights=weights, zero_grad=True)
        updates, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)

    # weight = weight_start * (1 - anneal_weight) + anneal_weight * weight

    # L(opt(theta)) with l_opt_weights
    # history_grads, anneal_weight
    # output layers: 60,61;
    # penalty_term = l_opt_weights[60] * torch.norm(updates[60], p=1) \
    #     + l_opt_weights[61] * torch.norm(updates[61], p=1)

    # updates, grads = optimizer.true_second_step(weights=weights, zero_grad=True)
    # updates, grads = optimizer.true_second_step_with_grad(weights=weights, grads=None, zero_grad=True)

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss, grads

@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_si_bitta_abl(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                                       RegLoss, l_opt_k, history_grads, anneal_weight, backtrack_degree, base_optimizer):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0, None
        # ema, reset_flag, tclscl_loss, grads

    # adapt
    tclscl_loss.backward()
        
    optimizer.first_step(zero_grad=True) # compute \hat{\epsilon(\Theta)} for first order approximation, Eqn. (4)

    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16
    # # second time backward, update model weights using gradients at \Theta+\hat{\epsilon(\Theta)}
    # tclscl_loss.backward(retain_graph=True)
    # # RuntimeError: Only Tensors created explicitly by the user (graph leaves) support the deepcopy protocol at the moment
    # # tclscl_loss_copy = deepcopy(tclscl_loss)

    # # optimizer.second_step(weights=opt_l_weights, zero_grad=True)
    
    # updates, grads = optimizer.before_second_step()    
    # # new penalty: penalize all layers
    # penalty_term = None
    # for update in updates:
    #     if update == None: continue
    #     if penalty_term == None: penalty_term = torch.norm(update, p=1)
    #     else: penalty_term = penalty_term + torch.norm(update, p=1)
    # tclscl_loss = tclscl_loss + l_opt_k*penalty_term
    # tclscl_loss.backward()

    # updates, grads_raw = optimizer.before_second_step()

    # adapt
    tclscl_loss.backward()
    # updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads_raw_first = base_optimizer.step_no_update(zero_grad=True)

    # re-calculate tclscl
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16

    # new penalty: penalize all layers
    tclscl_loss_re = tclscl_loss_re + l_opt_k * RegLoss(updates)
    if l_opt_k == 0: assert tclscl_loss.item() == tclscl_loss_re.item(), f"tclscl_loss:{tclscl_loss.item()} != tclscl_loss_re:{tclscl_loss_re.item()}"
    tclscl_loss_re.backward()

    updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads = optimizer.true_second_step_with_grad(grads=grads_raw, zero_grad=True)

    # weight = weight_start * (1 - anneal_weight) + anneal_weight * weight

    # L(opt(theta)) with l_opt_weights
    # history_grads, anneal_weight
    # output layers: 60,61;
    # penalty_term = l_opt_weights[60] * torch.norm(updates[60], p=1) \
    #     + l_opt_weights[61] * torch.norm(updates[61], p=1)

    # updates, grads = optimizer.true_second_step(weights=weights, zero_grad=True)
    # updates, grads = optimizer.true_second_step_with_grad(weights=weights, grads=None, zero_grad=True)

    # print(f'Time used in iter_{iter_num}/tta_{tta_step}')

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss, grads


@torch.enable_grad()  # ensure grads in possible no grad context for testing
def forward_and_adapt_prior_si(x, x_aug, tta_step, iter_num, save_grad, model, optimizer, margin, reset_constant, ema, TCLoss, SCLoss, k16, save_path,
                               RegLoss, l_opt_k, history_grads, anneal_weight, sam_weight, backtrack_degree, base_optimizer, disable_bd):
    """Forward and adapt model input data.
    Measure entropy of the model prediction, take gradients, and update params.
    """
    optimizer.zero_grad()
    # forward
    # outputs= model(x)
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)

    # Prior
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss = (sc_loss*0.001 + tc_loss*0.01) * k16

    if margin <= abs(tclscl_loss):
        outputs= model(x)
        print(f"==> TCLSCL Loss {tclscl_loss.detach().cpu().numpy()} > Margin {margin}, at TTA Step {tta_step}, Iter {iter_num}, model param. remains unchanged.")
        return outputs, ema, False, tclscl_loss*0.0, None
        # ema, reset_flag, tclscl_loss, grads

    # adapt
    tclscl_loss.backward()
    # updates, grads_raw = optimizer.before_second_step(zero_grad=True)
    updates, grads_raw_first = base_optimizer.step_no_update(zero_grad=True)

    # re-calculate tclscl
    bvp_pre_all, em_all, bvp_pre, HR_pr, HR_C_pr, av = model(x)
    bvp_pre_aug_all, em_aug_all, bvp_pre_aug, HR_pr_aug, HR_C_pr_aug, av_aug = model(x_aug)
    tc_loss = TCLoss(torch.squeeze(HR_pr), torch.squeeze(HR_pr_aug))
    sc_loss_0 = SCLoss(em_all[0])
    sc_loss_1 = SCLoss(em_all[1])
    sc_loss_2 = SCLoss(em_all[2])
    sc_loss_3 = SCLoss(em_all[3])
    sc_loss_aug_0 = SCLoss(em_aug_all[0])
    sc_loss_aug_1 = SCLoss(em_aug_all[1])
    sc_loss_aug_2 = SCLoss(em_aug_all[2])
    sc_loss_aug_3 = SCLoss(em_aug_all[3])
    sc_loss = sc_loss_0 + sc_loss_1 + sc_loss_2 + sc_loss_3 + sc_loss_aug_0 + sc_loss_aug_2 + sc_loss_aug_3 + sc_loss_aug_1
    tclscl_loss_re = (sc_loss*0.001 + tc_loss*0.01) * k16 * sam_weight

    # new penalty: penalize all layers
    tclscl_loss_re = tclscl_loss_re + l_opt_k * RegLoss(updates)
    if l_opt_k == 0 and sam_weight == 1.0: assert tclscl_loss.item() == tclscl_loss_re.item(), f"tclscl_loss:{tclscl_loss.item()} != tclscl_loss_re:{tclscl_loss_re.item()}"
    tclscl_loss_re.backward()

    updates, grads_raw = optimizer.step_no_update()

    if history_grads != None and disable_bd == False:
        similarity, projection = calculate_projection_similarity(history_grads, grads_raw)
        # print("TODO weight = f(history_grads, grads)")
        # haodongli @ 2023年11月15日16点55分
        # grads_new = sim_to_grads(similarity, grads_raw, backtrack_degree=backtrack_degree)
        grads_new = sim_to_grads(similarity, projection, backtrack_degree=backtrack_degree)
        # grads_new = sim_to_grads_new(similarity, projection, grads_raw, backtrack_degree=backtrack_degree)
        
        grads_out = []
        for (i, grad_raw) in enumerate(grads_raw):
            if grad_raw == None: 
                grads_out.append(None)
                continue
            grads_out.append(grad_raw*(1-anneal_weight) + grads_new[i]*anneal_weight)
        # _, updates, grads = optimizer.step_with_grad(grads=grads_out)
        _, updates, grads = optimizer.step_with_grad_nograd(grads=grads_out)
    else:
        # updates, grads = optimizer.step_with_grad(grads=grads_raw)
        _, updates, grads = optimizer.step_with_grad_nograd(grads=grads_raw)

    # perform model recovery
    reset_flag = False
    if ema is not None:
        if ema < 0.2:
            print("ema < 0.2, now reset the model")
            reset_flag = True
    model.eval()
    outputs = model(x)
    return outputs, ema, reset_flag, tclscl_loss, grads

def collect_params(model):
    """Collect the affine scale + shift parameters from norm layers.
    Walk the model's modules and collect all normalization parameters.
    Return the parameters and their names.
    Note: other choices of parameterization are possible!
    """
    params = []
    names = []
    for nm, m in model.named_modules():
        # skip top layers for adaptation: layer4 for ResNets and blocks9-11 for Vit-Base
        if 'layer4' in nm:
            continue
        if 'blocks.9' in nm:
            continue
        if 'blocks.10' in nm:
            continue
        if 'blocks.11' in nm:
            continue
        if 'norm.' in nm:
            continue
        if nm in ['norm']:
            continue

        if isinstance(m, (nn.BatchNorm2d, nn.LayerNorm, nn.GroupNorm)):
            for np, p in m.named_parameters():
                if np in ['weight', 'bias']:  # weight is scale, bias is shift
                    params.append(p)
                    names.append(f"{nm}.{np}")

    return params, names

def collect_params_new(model):
    params = []
    names = []
    for nm, m in model.named_modules():
        for np, p in m.named_parameters():
            if np in ['weight', 'bias']:  # weight is scale, bias is shift
                params.append(p)
                names.append(f"{nm}.{np}")

    return params, names


def copy_model_and_optimizer(model, optimizer):
    """Copy the model and optimizer states for resetting after adaptation."""
    model_state = deepcopy(model.state_dict())
    optimizer_state = deepcopy(optimizer.state_dict())
    return model_state, optimizer_state


def load_model_and_optimizer(model, optimizer, model_state, optimizer_state):
    """Restore the model and optimizer states from copies."""
    model.load_state_dict(model_state, strict=True)
    optimizer.load_state_dict(optimizer_state)

def configure_model_new(model):
    """Configure model for use with SAR."""
    # train mode, because SAR optimizes the model to minimize entropy
    model.train()
    # disable grad, to (re-)enable only what SAR updates
    # model.requires_grad_(False)
    # configure norm for SAR updates: enable grad + force batch statisics (this only for BN models)
    # for m in model.modules():
    #     if isinstance(m, nn.BatchNorm2d):
    #         m.requires_grad_(True)
    #         # force use of batch stats in train and eval modes
    #         m.track_running_stats = False
    #         m.running_mean = None
    #         m.running_var = None
        # LayerNorm and GroupNorm for ResNet-GN and Vit-LN models
        # if isinstance(m, (nn.LayerNorm, nn.GroupNorm)):
        #     m.requires_grad_(True)
    return model

def configure_model(model):
    """Configure model for use with SAR."""
    # train mode, because SAR optimizes the model to minimize entropy
    model.train()
    # disable grad, to (re-)enable only what SAR updates
    model.requires_grad_(False)
    # configure norm for SAR updates: enable grad + force batch statisics (this only for BN models)
    for m in model.modules():
        if isinstance(m, nn.BatchNorm2d):
            m.requires_grad_(True)
            # force use of batch stats in train and eval modes
            m.track_running_stats = False
            m.running_mean = None
            m.running_var = None
        # LayerNorm and GroupNorm for ResNet-GN and Vit-LN models
        if isinstance(m, (nn.LayerNorm, nn.GroupNorm)):
            m.requires_grad_(True)
    return model


def check_model(model):
    """Check model for compatability with SAR."""
    is_training = model.training
    assert is_training, "SAR needs train mode: call model.train()"
    param_grads = [p.requires_grad for p in model.parameters()]
    has_any_params = any(param_grads)
    has_all_params = all(param_grads)
    assert has_any_params, "SAR needs params to update: " \
                           "check which require grad"
    assert not has_all_params, "SAR should not update all params: " \
                               "check which require grad"
    has_norm = any([isinstance(m, (nn.BatchNorm2d, nn.LayerNorm, nn.GroupNorm)) for m in model.modules()])
    assert has_norm, "SAR needs normalization layer parameters for its optimization"

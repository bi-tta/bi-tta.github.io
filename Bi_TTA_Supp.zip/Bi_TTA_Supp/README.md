# Bi-TTA: Bidirectional Test-Time Adapter for Remote Physiological Measurement

**This implementation is based on [EnVision-Research/NEST-rPPG](https://github.com/EnVision-Research/NEST-rPPG).**

### Abstract
Remote photoplethysmography (rPPG) is gaining prominence for its non-invasive approach to monitoring physiological signals using only cameras. Despite its promise, the adaptability of rPPG models to new, unseen domains is hindered due to the environmental sensitivity of physiological signals. To address this issue, we pioneer the Test-Time Adaptation (TTA) in rPPG, enabling the adaptation of pre-trained models to the target domain during inference, sidestepping the need for annotations or source data due to privacy considerations. Particularly, utilizing only the user's face video stream as the accessible target domain data, the rPPG model is adjusted by tuning on each single instance it encounters. However, 1) TTA algorithms are designed predominantly for classification tasks, ill-suited in regression tasks such as rPPG due to inadequate supervision. 2) Tuning pre-trained models in a single-instance manner introduces variability and instability, posing challenges to effectively filtering domain-relevant from domain-irrelevant features while simultaneously preserving the learned information. To overcome these challenges, we present \textbf{Bi-TTA}, a novel domain knowledge-based \textbf{Bi}directional \textbf{T}est-\textbf{T}ime \textbf{A}dapter framework. Specifically, leveraging two expert-knowledge priors for providing self-supervision, our Bi-TTA primarily comprises two modules: a prospective adaptation (PA) module using sharpness-aware minimization to eliminate domain-irrelevant noise, enhancing the stability and efficacy during the adaptation process, and a retrospective stabilization (RS) module to dynamically reinforce crucial learned model parameters, averting performance degradation caused by overfitting or catastrophic forgetting. To this end, we established a large-scale benchmark for rPPG tasks under TTA protocol, promoting advancements in both the rPPG and TTA fields. The experimental results demonstrate the significant superiority of our approach over the state-of-the-art (SoTA).

### Environment

```
conda env create -f environment.yml
```

### Dataset

Please download the generated STMap and trained models for each target domain (*i.e.*, VIPL, UBFC, BUAA, PURE, V4V) from [Google Drive](https://drive.google.com/drive/folders/1U9yvTTJASf97viPVlLFxoYhiE4OqacLw?usp=sharing) or [Baidu Drive](https://pan.baidu.com/s/1_rmxLbLOGjRRdDU2niNwSQ) (temporary key: eccv).

### Run!

```
conda activate bitta
bash run.sh
```

### Evaluation

Please refer to [EnVision-Research/NEST-rPPG](https://github.com/EnVision-Research/NEST-rPPG) for detailed instructions of model evaluation.

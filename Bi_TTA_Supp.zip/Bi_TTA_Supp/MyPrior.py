import torch
import torch.nn as nn
import torch.nn.functional as F 
from torchvision.models import resnet18
import numpy as np

# self.TCLoss = MyPrior.temporal_loss(k15)
# self.SCLoss = MyPrior.SpatialConsistencyLoss2()

class ModelParamReg(nn.Module):
    def __init__(self):
        super().__init__()
        # self.L1Loss = nn.L1Loss()
        self.L2Loss = nn.MSELoss()

    def forward(self, updates):
        penalty_term = None
        for update in updates:
            if update == None: continue
            if penalty_term == None: 
                penalty_term = self.L2Loss(input=update, 
                                           target=torch.zeros_like(update))
            else: 
                penalty_term = penalty_term + self.L2Loss(input=update, 
                                                          target=torch.zeros_like(update))
        return penalty_term

class SpatialConsistencyLoss(nn.Module):
    def __init__(self, ratio=0.5):
        super().__init__()
        self.ratio = ratio
        self.L1Loss = nn.L1Loss()

    def forward(self, FeatureMap):
        B, C, W, L = FeatureMap.shape
        randm_size = int(self.ratio * W)
        if randm_size <= 0:
            randm_size = 1
        Index1 = np.random.randint(W, size=randm_size)
        Index2 = np.random.randint(W, size=randm_size)
        gt_lable = FeatureMap[:, :, Index1, :].clone().requires_grad_()
        pre_lable = FeatureMap[:, :, Index2, :].clone().requires_grad_()
        loss = self.L1Loss(gt_lable, pre_lable)/((C*randm_size*L)/256)
        return loss


class temporal_loss(nn.Module):
    def __init__(self, thr=1):
        super(temporal_loss, self).__init__()
        self.L1Loss = nn.L1Loss()
        self.thr = thr

    def forward(self, pre, gt):  # all variable operation
        temp = torch.abs(pre-gt)

        return self.L1Loss(torch.squeeze(torch.where(temp >= self.thr, pre, gt)), torch.squeeze(gt))


class SpatialConsistencyLoss2(nn.Module):
    def __init__(self, ratio=0.5):
        super().__init__()
        self.ratio = ratio
        self.L1Loss = nn.L1Loss()

    def forward(self, FeatureMap):
        B, C, W, L = FeatureMap.shape
        loss = self.L1Loss(FeatureMap[:, :, 0:W-1, :], FeatureMap[:, :, 1:, :])/((C*W*L)/256)
        return loss



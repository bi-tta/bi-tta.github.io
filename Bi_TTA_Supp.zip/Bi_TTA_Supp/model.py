# -*- coding: UTF-8 -*-
import torch.nn as nn
import torch
import torch.nn.functional as F
import sys
import utils
from torchvision import models
import numpy as np

np.set_printoptions(threshold=np.inf)
sys.path.append('..')


class BasicBlock(nn.Module):
    def __init__(self, inplanes, out_planes, stride=2, downsample=1, Res=0):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(inplanes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.BatchNorm2d(out_planes),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(out_planes, out_planes, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_planes),
        )
        if downsample == 1:
            self.down = nn.Sequential(
                nn.Conv2d(inplanes, out_planes, kernel_size=1, stride=stride, padding=0, bias=False),
                nn.BatchNorm2d(out_planes)
                 )
        self.downsample = downsample
        self.Res = Res

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        if self.Res == 1:
            if self.downsample == 1:
                x = self.down(x)
            out += x
        return F.relu(out)


class BaseNet(nn.Module):
    def __init__(self):
        super(BaseNet, self).__init__()
        self.range = 121  # 40-160
        model_resnet = models.resnet18(pretrained=True)
        self.conv1 = model_resnet.conv1
        self.bn1 = model_resnet.bn1
        self.relu = model_resnet.relu
        self.layer1 = model_resnet.layer1
        self.layer2 = model_resnet.layer2
        self.layer3 = model_resnet.layer3
        self.layer4 = model_resnet.layer4



        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, 1)
        #  Classification Auxiliary Task used for TTA
        self.fc_classification = nn.Linear(512, self.range)

        self.up1 = nn.Sequential(
            nn.ConvTranspose2d(512, 512, kernel_size=[1, 2], stride=[1, 2]),
            BasicBlock(512, 256, [2, 1], downsample=1),
        )
        self.up2 = nn.Sequential(
            nn.ConvTranspose2d(256, 256, kernel_size=[1, 2], stride=[1, 2]),
            BasicBlock(256, 64, [1, 1], downsample=1),
        )
        self.up3 = nn.Sequential(
            nn.ConvTranspose2d(64, 64, kernel_size=[2, 2], stride=[1, 2]),
            BasicBlock(64, 32, [2, 1], downsample=1),
        )
        self.up4 = nn.Sequential(
            nn.ConvTranspose2d(32, 32, kernel_size=[2, 2], stride=[1, 2]),
            BasicBlock(32, 1, [1, 1], downsample=1),
        )



    def get_av(self, x):
        av = torch.mean(torch.mean(x, dim=-1), dim=-1)
        min, _ = torch.min(av, dim=1, keepdim=True)
        max, _ = torch.max(av, dim=1, keepdim=True)
        av = torch.mul((av-min),((max-min).pow(-1)))
        return av
    def forward(self, x):

        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)

        em1 = self.layer1(x)
        av1 = self.get_av(em1)
        em2 = self.layer2(em1)
        av2 = self.get_av(em2)
        em3 = self.layer3(em2)
        av3 = self.get_av(em3)
        em = self.layer4(em3)
        av4 = self.get_av(em)

        # # prior
        # SCLloss = self.SCLoss(em1) + self.SCLoss(em2) + self.SCLoss(em3) + self.SCLoss(em) # em4 = em
        em_all = [em1, em2, em3, em]

        av = torch.cat([av1, av2, av3, av4], dim=1)

        HR = self.fc(self.avgpool(em).view(x.size(0), -1))
        HR_C = self.fc_classification(self.avgpool(em).view(x.size(0), -1))
        
        # prior
        # TCLoss =self.TCLoss(torch.squeeze(f3), torch.squeeze(HR))

        # For Sig
        x = self.up1(em)
        x = self.up2(x)
        x = self.up3(x)
        Sig = self.up4(x)
        Sig_avg = []
        for a in range(Sig.shape[2]):
            Sig_avg.append(Sig[:, :, a, :]) # (B, 1, T)

        Sig_avg = sum(Sig_avg)/(Sig.shape[2]) # (B, 1, T)
        Sig = Sig.squeeze(dim=1)

        # B, N, T
        return Sig, em_all, Sig_avg, HR, HR_C, av


class GRL(torch.autograd.Function):

    # 重写父类方法的时候，最好添加默认参数，不然会有warning（为了好看。。）
    @ staticmethod
    def forward(ctx, x, lambd, **kwargs: None):
        #　其实就是传入dict{'lambd' = lambd}
        ctx.lambd = lambd
        return x.view_as(x)

    @staticmethod
    def backward(ctx, *grad_output):
        # 传入的是tuple，我们只需要第一个
        return grad_output[0] * -ctx.lambd, None

    # 这样写是没有warning，看起来很舒服，但是显然是多此一举咯，所以也可以改写成

    def backward(ctx, grad_output):
        # 直接传入一格数
        return grad_output * -ctx.lambd, None


class cls_head(nn.Module):
    def __init__(self):
        super(cls_head, self).__init__()
        self.range = 121
        self.fc_classification = nn.Linear(512, self.range)
        self.fc_classification_bi = nn.Linear(512, 2) # aug or not
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.softmax = nn.Softmax()

    def forward(self, feature):
        # out = self.fc_classification(self.avgpool(GRL.apply(feature, 1.0)).view(feature.shape[0], -1))
        out = self.fc_classification(self.avgpool(feature).view(feature.shape[0], -1))
        out_bi = self.softmax(self.fc_classification_bi(self.avgpool(feature).view(feature.shape[0], -1)))
        return out, out_bi


if __name__ == '__main__':
    net = BaseNet()
    Sig, em_all, Sig_avg, HR, HR_C, av = net(torch.randn(1, 3, 300, 300))
    # print the output shape of layer 1-4
    for i in range(1, 5):
        print(em_all[i-1].shape)

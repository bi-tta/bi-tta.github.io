gpu_ids=1
weighted_trend=True
bd=-9.0
rho=0.005
target_domain=VIPL
python train_prior_bitta.py \
    -g $gpu_ids \
    -t $target_domain  \
    -m 'bitta'  \
    --reData 1 \
    -mi 8349  \
    --save_path 'Out_'$target_domain'_HP'$rho'_'$bd \
    -rT 1 -b 1  \
    -l 0.001  \
    -k15 8  \
    -fixed True  \
    -s 0  \
    --test_pretrained 1 \
    -k16 1.0  \
    -k17 0.001  \
    -k18 0.01  \
    --new_lr 0.0001 \
    --tta_steps 2 \
    --tta_method bitta_si_ema_prior \
    --ema_param 0.0 \
    --bitta_rho $rho \
    --backtrack_degree $bd \
    --weighted_trend $weighted_trend \
    --interval_sampling True 

# -*- coding: UTF-8 -*-
import numpy as np
import scipy.io as io
import torch
import MyDataset
import MyLoss
import model
import math
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.autograd import Variable
from torchvision import transforms
import utils
from datetime import datetime
import os
import time
from utils import Logger, time_to_str
from timeit import default_timer as timer
import time
import random
import copy

from sam import SAM
from copy import deepcopy

from tqdm import tqdm
import MyPrior
import tta_prior
import si_sgd_new

# haodongli at 2023年11月17日17点41分, for better robust during adaptation
import si_sam
# print("==> import si_sam_random as si_sam")
# import si_sam_random as si_sam

# import tta_prior_si

TARGET_DOMAIN = {'VIPL': ['V4V',  'PURE', 'BUAA', 'UBFC'], \
                 'V4V': ['VIPL',  'PURE', 'BUAA', 'UBFC'], \
                 'PURE': ['VIPL', 'V4V', 'BUAA', 'UBFC'], \
                 'BUAA': ['VIPL', 'V4V', 'PURE', 'UBFC'], \
                 'UBFC': ['VIPL', 'V4V', 'PURE', 'BUAA']}

FILEA_NAME = {'VIPL': ['VIPL', 'VIPL', 'STMap_RGB_Align_CSI'], \
              'V4V': ['V4V', 'V4V', 'STMap_RGB'], \
              'PURE': ['PURE', 'PURE', 'STMap'], \
              'BUAA': ['BUAA', 'BUAA', 'STMap_RGB'], \
              'UBFC': ['UBFC', 'UBFC', 'STMap']}

if __name__ == '__main__':


    args = utils.get_args()
    seed = args.seed
    if seed == 0:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    else:
        print('random seed')
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    Source_domain_Names = TARGET_DOMAIN[args.tgt]
    root_file = r'./STMap/'
    # 参数

    FILE_Name = FILEA_NAME[args.tgt]
    Target_name = args.tgt
    Target_fileRoot = root_file + FILE_Name[0]
    Target_saveRoot = root_file + 'STMap_Index/' + FILE_Name[1]
    Target_map = FILE_Name[2] + '.png'
    
    # 训练参数
    batch_size_num = args.batchsize
    epoch_num = args.epochs
    learning_rate = args.lr

    test_batch_size = args.batchsize
    num_workers = args.num_workers
    GPU = args.GPU

    # 图片参数
    input_form = args.form
    reTrain = args.reTrain
    frames_num = args.frames_num
    fold_num = args.fold_num
    fold_index = args.fold_index

    best_mae = 99

    print('batch num:', batch_size_num, ' epoch_num:', epoch_num, ' GPU Inedex:', GPU)
    print(' frames num:', frames_num, ' learning rate:', learning_rate, )
    print('fold num:', frames_num, ' fold index:', fold_index, ' method:', args.method, ' fixed:', args.fixed)
    print('save_path:', args.save_path, ' tta_method:', args.tta_method)
    if args.TODO_MODE == False and 'TODO' in args.tta_method: args.TODO_MODE = True

    if not os.path.exists(args.save_path): os.mkdir(args.save_path)
    if not os.path.exists('./' + args.save_path + f'/Result_log'):
        os.makedirs('./' + args.save_path + f'/Result_log')
    rPPGNet_name_raw_pretrained = Target_name + '/rPPGNet_' + Target_name + 'TTA'
    rPPGNet_name_raw = 'rPPGNet_' + Target_name + 'TTA'
    log = Logger()
    log.open('./' + args.save_path + f'/Result_log/' + 'rPPGNet_' + Target_name + 'TTA' + '_log.txt', mode='a')
    log.write("\n----------------------------------------------- [START %s] %s\n\n" % (
        datetime.now().strftime('%Y-%m-%d %H:%M:%S'), '-' * 51))

    # 运行媒介
    if torch.cuda.is_available():
        device = torch.device('cuda:' + GPU if torch.cuda.is_available() else 'cpu')  #
        print('on GPU')
    else:
        print('on CPU')

    # 数据集
    if args.reData == 1:
        Target_index = os.listdir(Target_fileRoot)

        Target_Index = MyDataset.getIndex(Target_fileRoot, Target_index, 
                                           Target_saveRoot, Target_map, 10, frames_num)

    Target_db = MyDataset.Data_TTA(root_dir=Target_saveRoot, dataName=Target_name, 
                                  STMap=Target_map, frames_num=frames_num, args=args,
                                  interval_sampling=args.interval_sampling, interval=args.interval)

    tgt_loader = DataLoader(Target_db, batch_size=batch_size_num, shuffle=False, num_workers=num_workers)

    # Target_db_full = MyDataset.Data_TTA(root_dir=Target_saveRoot, dataName=Target_name, 
    #                                    STMap=Target_map, frames_num=frames_num, args=args)

    # tgt_loader_full = DataLoader(Target_db_full, batch_size=batch_size_num, shuffle=False, num_workers=num_workers)

    # BaseNet = model.BaseNet()

    loss_func_NP = MyLoss.P_loss3().to(device)
    loss_func_L1 = nn.L1Loss().to(device)
    loss_func_CE = nn.CrossEntropyLoss().to(device)
    loss_func_cov = MyLoss.Cov_loss().to(device)
    loss_func_dig = MyLoss.Cov_Dig_loss2().to(device)
    loss_func_con = MyLoss.contrast_loss().to(device)
    loss_func_SP = MyLoss.SP_loss(device, clip_length=frames_num).to(device)
    loss_func_smooth = MyLoss.Smooth_loss3(device, Num_ref=8).to(device)
    SCLoss = MyPrior.SpatialConsistencyLoss2()
    L1Loss = nn.L1Loss()
    TCLoss = MyPrior.temporal_loss(args.k15)

    if reTrain == 1:
        BaseNet = torch.load('./' + rPPGNet_name_raw_pretrained, map_location=device)
        print('load ' + rPPGNet_name_raw_pretrained + ' right')
    BaseNet.to(device=device)

    tgt_iter = iter(tgt_loader)
    tgt_iter_per_epoch = len(tgt_iter)

    max_iter = args.max_iter
    start = timer()

    loss_mean = []
    Label_pr = []
    Label_gt = []
    HR_pr_temp = []
    HR_rel_temp = []
    HR_pr2_temp = []
    BVP_ALL = []
    BVP_PR_ALL = []

    # before TTA
    if args.test_pretrained != 0:
        for tta_step, (data, bvp, HR_rel, _, _, _) in enumerate(tqdm(tgt_loader)):
            data = Variable(data).float().to(device=device)
            bvp = Variable(bvp).float().to(device=device)
            HR_rel = Variable(HR_rel).float().to(device=device)
            bvp = bvp.unsqueeze(dim=1)
            Wave = bvp
            _, _, Wave_pr, HR_pr, HR_C_pr, av = BaseNet(data)

            if Target_name in ['VIPL', 'V4V', 'PURE']:
                HR_rel_temp.extend(HR_rel.data.cpu().numpy())
                HR_pr_temp.extend(HR_pr.data.cpu().numpy())
                BVP_ALL.extend(Wave.data.cpu().numpy())
                BVP_PR_ALL.extend(Wave_pr.data.cpu().numpy())
            else:
                temp, HR_rel = loss_func_SP(Wave, HR_rel)
                HR_rel_temp.extend(HR_rel.data.cpu().numpy())
                temp, HR_pr = loss_func_SP(Wave_pr, HR_pr)
                HR_pr_temp.extend(HR_pr.data.cpu().numpy())
                BVP_ALL.extend(Wave.data.cpu().numpy())
                BVP_PR_ALL.extend(Wave_pr.data.cpu().numpy())

        print(f'Before TTA:')
        ME, STD, MAE, RMSE, MER, P = utils.MyEval(HR_pr_temp, HR_rel_temp)
        log.write(
            'Test Inter:' + str(-1) \
            + ' | ME:  ' + str(ME) \
            + ' | STD: ' + str(STD) \
            + ' | MAE: ' + str(MAE) \
            + ' | RMSE: ' + str(RMSE) \
            + ' | MER: ' + str(MER) \
            + ' | P '  + str(P) \
            + ' | testing time ' + time_to_str(timer() - start, 'min'))
        log.write('\n')

        if not os.path.exists('./' + args.save_path + f'/Result_Model'):
            os.makedirs('./' + args.save_path + f'/Result_Model')

        # if best_mae > MAE or args.fixed:
        #     best_mae = MAE
        if not os.path.exists('./' + args.save_path + f'/Result'):
            os.makedirs('./' + args.save_path + f'/Result')
        if not os.path.exists('./' + args.save_path + f'/Result/HR_pr'):
            os.makedirs('./' + args.save_path + f'/Result/HR_pr')
        if not os.path.exists('./' + args.save_path + f'/Result/HR_rel'):
            os.makedirs('./' + args.save_path + f'/Result/HR_rel')
        if not os.path.exists('./' + args.save_path + f'/Result/WAVE_ALL'):
            os.makedirs('./' + args.save_path + f'/Result/WAVE_ALL')
        if not os.path.exists('./' + args.save_path + f'/Result/WAVE_PR_ALL'):
            os.makedirs('./' + args.save_path + f'/Result/WAVE_PR_ALL')   
        rPPGNet_name = rPPGNet_name_raw
        io.savemat('./' + args.save_path + f'/Result/HR_pr/' + rPPGNet_name + 'HR_pr' + '_iter.mat', {'HR_pr': HR_pr_temp})
        io.savemat('./' + args.save_path + f'/Result/HR_rel/' + rPPGNet_name + 'HR_rel' + '_iter.mat', {'HR_rel': HR_rel_temp})
        # io.savemat('./' + args.save_path + f'/Result/WAVE_ALL/' + rPPGNet_name + 'WAVE_ALL' + '_iter.mat',
        #             {'Wave': BVP_ALL})
        # io.savemat('./' + args.save_path + f'/Result/WAVE_PR_ALL/' + rPPGNet_name + 'WAVE_PR_ALL' + '_iter.mat',
        #             {'Wave': BVP_PR_ALL})
        # torch.save(deepcopy(BaseNet), './' + args.save_path + f'/Result_Model/' + rPPGNet_name + '_iter')
        print('saveModel As ' + rPPGNet_name)

    if not os.path.exists('./' + args.save_path + f'/Result_Gradient'):
        os.makedirs('./' + args.save_path + f'/Result_Gradient')

    total_iter = len(tgt_loader)
    max_iter = max_iter//total_iter
    print(max_iter, total_iter, max_iter * total_iter)
    TCLSCL_loss_log = {}
    if args.TODO_MODE:
        print(f"==> args.TODO_MODE is {args.TODO_MODE}, args.TODO_interval = {args.TODO_interval}, args.sim_matrix = {args.sim_matrix}")
        TCLSCL_grad_sim_log = {}
        TCLSCL_grad_norm_log = {}
        TCLSCL_grad_std_log = {}
        TODO_sim_matrix = args.sim_matrix # 'pearsonr', or default: 'cosine'

    for iter_num in range(max_iter):
        # idealy, max_iter=1, tta_steps=2

        # TTA
        if args.tta_method == 'prior':
            base_optimizer = torch.optim.SGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              base_optimizer, 
                                              margin_e0=math.log(1000) * 0.40, 
                                              steps=args.tta_steps, tta_method=args.tta_method)
        elif args.tta_method == 'ema_prior':
            base_optimizer = torch.optim.SGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              base_optimizer, 
                                              margin_e0=math.log(1000) * 0.40, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param)
        elif args.tta_method == 'bitta_prior':
            base_optimizer = torch.optim.SGD
            optimizer_tta = SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                rho=args.bitta_rho)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method)
        elif args.tta_method == 'bitta_GT_TODO':
            # base_optimizer = torch.optim.SGD
            # optimizer_tta = SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
            #                     rho=args.bitta_rho)
            base_optimizer = si_sgd_new.CombinedCustomSGD
            optimizer_tta = si_sam.SI_SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                          rho=args.bitta_rho)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method,
                                              args=args, sim_matrix=TODO_sim_matrix)
        elif args.tta_method == 'prior_TODO':
            base_optimizer = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              base_optimizer, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method,
                                              sim_matrix=TODO_sim_matrix, args=args)
        elif args.tta_method == 'bitta_prior_TODO':
            # base_optimizer = torch.optim.SGD
            # optimizer_tta = SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
            #                     rho=args.bitta_rho)
            base_optimizer = si_sgd_new.CombinedCustomSGD
            optimizer_tta = si_sam.SI_SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                          rho=args.bitta_rho)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method,
                                              sim_matrix=TODO_sim_matrix, weighted_trend=args.weighted_trend)
        elif args.tta_method == 'bitta_ema_prior':
            base_optimizer = torch.optim.SGD
            optimizer_tta = SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                rho=args.bitta_rho)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param)
        elif args.tta_method == 'bitta_ema_prior_TODO':
            # base_optimizer = torch.optim.SGD
            # optimizer_tta = SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
            #                     rho=args.bitta_rho)
            base_optimizer = si_sgd_new.CombinedCustomSGD
            optimizer_tta = si_sam.SI_SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                          rho=args.bitta_rho)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param,
                                              sim_matrix=TODO_sim_matrix, weighted_trend=args.weighted_trend)
        elif 'bitta_ema_prior_abl' in args.tta_method:
            base_optimizer = si_sgd_new.CombinedCustomSGD
            optimizer_tta = si_sam.SI_SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                          rho=args.bitta_rho)
            base_optimizer = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param,
                                              base_optimizer=base_optimizer, args=args)
        elif args.tta_method == 'bitta_si_ema_prior':
            num_of_layers = 0
            for param in BaseNet.parameters(): num_of_layers += 1
            param_weights = [1.0 for _ in range(num_of_layers)]
            base_optimizer = si_sgd_new.CombinedCustomSGD
            # self.param_groups: [{'params': [...], 'rho': 0.005, 'adaptive': False, 'lr': 0.0001, 'momentum': 0.9}]
            print(f"==> tta_method is {args.tta_method}: new_lr = {args.new_lr}, regular_k = {args.l_opt_k}, args.disable_bd = {args.disable_bd}")
            optimizer_tta = si_sam.SI_SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                          rho=args.bitta_rho)
            base_optimizer = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param, 
                                              param_weights=param_weights, l_opt_k=args.l_opt_k,
                                              backtrack_degree=args.backtrack_degree,
                                              base_optimizer=base_optimizer, args=args)
        elif args.tta_method == 'bitta_si_ema_prior_abl':
            num_of_layers = 0
            for param in BaseNet.parameters(): num_of_layers += 1
            param_weights = [1.0 for _ in range(num_of_layers)]
            base_optimizer = si_sgd_new.CombinedCustomSGD
            # self.param_groups: [{'params': [...], 'rho': 0.005, 'adaptive': False, 'lr': 0.0001, 'momentum': 0.9}]
            print(f"==> tta_method is {args.tta_method}: new_lr = {args.new_lr}, regular_k = {args.l_opt_k}, args.disable_bd = {args.disable_bd}")
            optimizer_tta = si_sam.SI_SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                          rho=args.bitta_rho)
            base_optimizer = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param, 
                                              param_weights=param_weights, l_opt_k=args.l_opt_k,
                                              backtrack_degree=args.backtrack_degree,
                                              base_optimizer=base_optimizer, args=args)
        elif args.tta_method == 'si_ema_prior':
            # raise NotImplementedError
            num_of_layers = 0
            for param in BaseNet.parameters(): num_of_layers += 1
            param_weights = [1.0 for _ in range(num_of_layers)]
            base_optimizer = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            # self.param_groups: [{'params': [...], 'rho': 0.005, 'adaptive': False, 'lr': 0.0001, 'momentum': 0.9}]
            print(f"==> tta_method is {args.tta_method}: new_lr = {args.new_lr}, regular_k = {args.l_opt_k}, args.disable_bd = {args.disable_bd}")
            base_optimizer_2 = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              base_optimizer, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param, 
                                              param_weights=param_weights, l_opt_k=args.l_opt_k,
                                              backtrack_degree=args.backtrack_degree,
                                              base_optimizer=base_optimizer_2,
                                              disable_bd=args.disable_bd, args=args)
        elif args.tta_method == 'si_ema_prior_TODO':
            # raise NotImplementedError
            num_of_layers = 0
            for param in BaseNet.parameters(): num_of_layers += 1
            param_weights = [1.0 for _ in range(num_of_layers)]
            base_optimizer = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            # self.param_groups: [{'params': [...], 'rho': 0.005, 'adaptive': False, 'lr': 0.0001, 'momentum': 0.9}]
            print(f"==> tta_method is {args.tta_method}: new_lr = {args.new_lr}, regular_k = {args.l_opt_k}, args.disable_bd = {args.disable_bd}")
            base_optimizer_2 = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              base_optimizer, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param, 
                                              param_weights=param_weights, l_opt_k=args.l_opt_k,
                                              backtrack_degree=args.backtrack_degree,
                                              base_optimizer=base_optimizer_2,
                                              disable_bd=args.disable_bd,
                                              sim_matrix=TODO_sim_matrix, args=args)
        elif args.tta_method == 'bitta_si_ema_prior_TODO':
            num_of_layers = 0
            for param in BaseNet.parameters(): num_of_layers += 1
            param_weights = [1.0 for _ in range(num_of_layers)]
            base_optimizer = si_sgd_new.CombinedCustomSGD
            # self.param_groups: [{'params': [...], 'rho': 0.005, 'adaptive': False, 'lr': 0.0001, 'momentum': 0.9}]
            print(f"==> tta_method is {args.tta_method}: new_lr = {args.new_lr}, regular_k = {args.l_opt_k}, args.disable_bd = {args.disable_bd}")
            optimizer_tta = si_sam.SI_SAM(BaseNet.parameters(), base_optimizer, lr=args.new_lr, momentum=0.9, 
                                          rho=args.bitta_rho)
            base_optimizer = si_sgd_new.CombinedCustomSGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
            TTAed_model = tta_prior.TTA_Prior(BaseNet, 
                                              optimizer_tta, 
                                              margin_e0=args.bitta_margin, 
                                              steps=args.tta_steps, tta_method=args.tta_method, 
                                              ema_param=args.ema_param, 
                                              param_weights=param_weights, l_opt_k=args.l_opt_k,
                                              backtrack_degree=args.backtrack_degree,
                                              base_optimizer=base_optimizer,
                                              sim_matrix=TODO_sim_matrix, args=args)
        else:
            print(args.tta_method)
            raise NotImplementedError

        # Test_model = tta_prior.configure_model(BaseNet)
        # params, param_names = tta_prior.collect_params(Test_model)
        # base_optimizer = torch.optim.SGD(BaseNet.parameters(), lr=args.new_lr, momentum=0.9)
        # TTAed_model = tta_prior.TTA_Prior(Test_model, base_optimizer, margin_e0=math.log(1000) * 0.40)

        TTAed_model.set_prior_loss(args.k15, args.k16, args.k17, args.k18, args.save_path)

        loss_mean = []
        Label_pr = []
        Label_gt = []
        HR_pr_temp = []
        HR_rel_temp = []
        HR_pr2_temp = []
        BVP_ALL = []
        BVP_PR_ALL = []

        # save_grad = iter_num % args.save_info == 0 # haodong
        save_grad = iter_num in [] # haodong
        if save_grad:
            log.write(f"==> save_grad is {save_grad}, will save gradients at iter_{iter_num}")
            log.write('\n')
            if not os.path.exists(f'./' + args.save_path + f'/Result_Gradient/iter_{iter_num}'):
                os.makedirs(f'./' + args.save_path + f'/Result_Gradient/iter_{iter_num}')
        else:
            print(f"save_grad is False at iter {iter_num}/{max_iter}")

        # TTA
        test_start_time = timer()
        for tta_step, (data, bvp, HR_rel, data_aug, bvp_aug, HR_rel_aug) in enumerate(tqdm(tgt_loader)):
            # print(f"==> tta_step = {tta_step} !!!!!!!!!!", end='')

            # EMA, save_grad need this
            TTAed_model.set_info(tta_step=tta_step, iter_num=iter_num, save_grad=save_grad, 
                                 total_iter=args.tta_total_iter, total_iter_sam=args.tta_total_iter_sam)
            
            data = Variable(data).float().to(device=device)
            bvp = Variable(bvp).float().to(device=device)
            HR_rel = Variable(HR_rel).float().to(device=device)
            bvp = bvp.unsqueeze(dim=1)
            Wave = bvp

            data_aug = Variable(data_aug).float().to(device=device)
            bvp_aug = Variable(bvp_aug).float().to(device=device)
            HR_rel_aug = Variable(HR_rel_aug).float().to(device=device)
            bvp_aug = bvp_aug.unsqueeze(dim=1)
            Wave_aug = bvp_aug

            if args.TODO_MODE and args.tta_method == 'bitta_GT_TODO':
                _, _, Wave_pr, HR_pr, HR_C_pr, av = TTAed_model((data, bvp, HR_rel), 
                                                                (data_aug, bvp_aug, HR_rel_aug))
            else:
                _, _, Wave_pr, HR_pr, HR_C_pr, av = TTAed_model(data, data_aug)

            if args.TODO_MODE:
                # tta_loss, sim = TTAed_model.get_loss_sim_list()
                tta_loss, sim, grad_norm, grad_std = TTAed_model.get_loss_sim_grad_list()
                if str(tta_step) in TCLSCL_loss_log:
                    TCLSCL_loss_log[str(tta_step)].append(tta_loss)
                else:
                    TCLSCL_loss_log[str(tta_step)] = [tta_loss]

                # TODO haodongli, to vis. the grad. sim. & norm
                if str(tta_step) in TCLSCL_grad_sim_log:
                    TCLSCL_grad_sim_log[str(tta_step)].append(sim)
                else:
                    TCLSCL_grad_sim_log[str(tta_step)] = [sim]
                if str(tta_step) in TCLSCL_grad_norm_log:
                    TCLSCL_grad_norm_log[str(tta_step)].append(grad_norm)
                else:
                    TCLSCL_grad_norm_log[str(tta_step)] = [grad_norm]
                # TODO haodongli, add on 2023年11月10日
                if str(tta_step) in TCLSCL_grad_std_log:
                    TCLSCL_grad_std_log[str(tta_step)].append(grad_std)
                else:
                    TCLSCL_grad_std_log[str(tta_step)] = [grad_std]
            else:
                tta_loss = TTAed_model.get_loss_list()
                if str(tta_step) in TCLSCL_loss_log:
                    TCLSCL_loss_log[str(tta_step)].append(tta_loss)
                else:
                    TCLSCL_loss_log[str(tta_step)] = [tta_loss]

            if Target_name in ['VIPL', 'V4V', 'PURE']:
                HR_rel_temp.extend(HR_rel.data.cpu().numpy())
                HR_pr_temp.extend(HR_pr.data.cpu().numpy())
                BVP_ALL.extend(Wave.data.cpu().numpy())
                BVP_PR_ALL.extend(Wave_pr.data.cpu().numpy())
            else:
                temp, HR_rel = loss_func_SP(Wave, HR_rel)
                HR_rel_temp.extend(HR_rel.data.cpu().numpy())
                temp, HR_pr = loss_func_SP(Wave_pr, HR_pr)
                HR_pr_temp.extend(HR_pr.data.cpu().numpy())
                BVP_ALL.extend(Wave.data.cpu().numpy())
                BVP_PR_ALL.extend(Wave_pr.data.cpu().numpy())

            # haodnogli TODO's TODO_MODE to prove that the loss, gradient, 
            # and inference output oscillation is 
            # positively corresponded with the forgetting trend of the model
            if args.TODO_MODE and args.TODO_interval > 0 \
                and tta_step % (len(tgt_loader)//args.TODO_interval) == 0:
                # save_idx
                save_idx = tta_step // (len(tgt_loader)//args.TODO_interval) 
                # 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
                print(f"==> start evaluating at tta_step = {tta_step}, save_idx = {save_idx}")
                loss_mean_TODO = []
                Label_pr_TODO = []
                Label_gt_TODO = []
                HR_pr_temp_TODO = []
                HR_rel_temp_TODO = []
                HR_pr2_temp_TODO = []
                BVP_ALL_TODO = []
                BVP_PR_ALL_TODO = []

                test_start_time_TODO = timer()
                for tta_step_TODO, (data_TODO, bvp_TODO, HR_rel_TODO, _, _, _) in enumerate(tqdm(tgt_loader)):
                    
                    data_TODO = Variable(data_TODO).float().to(device=device)
                    bvp_TODO = Variable(bvp_TODO).float().to(device=device)
                    HR_rel_TODO = Variable(HR_rel_TODO).float().to(device=device)
                    bvp_TODO = bvp_TODO.unsqueeze(dim=1)
                    Wave_TODO = bvp_TODO

                    # haodongli, for validation only
                    _, _, Wave_pr_TODO, HR_pr_TODO, HR_C_pr_TODO, av_TODO = TTAed_model.model(data_TODO)

                    if Target_name in ['VIPL', 'V4V', 'PURE']:
                        HR_rel_temp_TODO.extend(HR_rel_TODO.data.cpu().numpy())
                        HR_pr_temp_TODO.extend(HR_pr_TODO.data.cpu().numpy())
                        BVP_ALL_TODO.extend(Wave_TODO.data.cpu().numpy())
                        BVP_PR_ALL_TODO.extend(Wave_pr_TODO.data.cpu().numpy())
                    else:
                        temp, HR_rel_TODO = loss_func_SP(Wave_TODO, HR_rel_TODO)
                        HR_rel_temp_TODO.extend(HR_rel_TODO.data.cpu().numpy())
                        temp, HR_pr_TODO = loss_func_SP(Wave_pr_TODO, HR_pr_TODO)
                        HR_pr_temp_TODO.extend(HR_pr_TODO.data.cpu().numpy())
                        BVP_ALL_TODO.extend(Wave_TODO.data.cpu().numpy())
                        BVP_PR_ALL_TODO.extend(Wave_pr_TODO.data.cpu().numpy())

                print(f'TTA at tta_step = {tta_step}, save_idx = {save_idx} [TODO]')
                ME, STD, MAE, RMSE, MER, P = utils.MyEval(HR_pr_temp_TODO, HR_rel_temp_TODO)
                log.write(
                    'Test Inter ' + str(iter_num) + f' @ tta_step = {tta_step}, save_idx = {save_idx} ' \
                    + ' | ME:  ' + str(ME) \
                    + ' | STD: ' + str(STD) \
                    + ' | MAE: ' + str(MAE) \
                    + ' | RMSE: ' + str(RMSE) \
                    + ' | MER: ' + str(MER) \
                    + ' | P '  + str(P) \
                    + ' | testing time ' + time_to_str(timer() - test_start_time_TODO, 'min'))
                log.write('\n')

                rPPGNet_name = rPPGNet_name_raw + f'_TODO_{save_idx}'
                io.savemat('./' + args.save_path + f'/Result/HR_pr/' + rPPGNet_name + 'HR_pr' + '_iter' + str(iter_num) + '.mat', {'HR_pr': HR_pr_temp_TODO})
                io.savemat('./' + args.save_path + f'/Result/HR_rel/' + rPPGNet_name + 'HR_rel' + '_iter' + str(iter_num) + '.mat', {'HR_rel': HR_rel_temp_TODO})
                # to save memory
                # io.savemat('./' + args.save_path + f'/Result/WAVE_ALL/' + rPPGNet_name + 'WAVE_ALL' + '_iter' + str(iter_num) + '.mat',
                #             {'Wave': BVP_ALL})
                # io.savemat('./' + args.save_path + f'/Result/WAVE_PR_ALL/' + rPPGNet_name + 'WAVE_PR_ALL' + '_iter' + str(iter_num) + '.mat',
                #             {'Wave': BVP_PR_ALL})
                # torch.save(deepcopy(TTAed_model.model), './' + args.save_path + f'/Result_Model/' + rPPGNet_name + '_iter' + str(iter_num))
                print('==> saveModel As ' + rPPGNet_name + '_iter' + str(iter_num))

        print(f'After TTA at {iter_num} [Average Test]')
        ME, STD, MAE, RMSE, MER, P = utils.MyEval(HR_pr_temp, HR_rel_temp)
        log.write(
            'Test Inter:' + str(iter_num) \
            + ' | ME:  ' + str(ME) \
            + ' | STD: ' + str(STD) \
            + ' | MAE: ' + str(MAE) \
            + ' | RMSE: ' + str(RMSE) \
            + ' | MER: ' + str(MER) \
            + ' | P '  + str(P) \
            + ' | testing time ' + time_to_str(timer() - test_start_time, 'min'))
        log.write('\n')

        rPPGNet_name = rPPGNet_name_raw + '_avg_test'
        io.savemat('./' + args.save_path + f'/Result/HR_pr/' + rPPGNet_name + 'HR_pr' + '_iter' + str(iter_num) + '.mat', {'HR_pr': HR_pr_temp})
        io.savemat('./' + args.save_path + f'/Result/HR_rel/' + rPPGNet_name + 'HR_rel' + '_iter' + str(iter_num) + '.mat', {'HR_rel': HR_rel_temp})
        io.savemat('./' + args.save_path + f'/Result/WAVE_ALL/' + rPPGNet_name + 'WAVE_ALL' + '_iter' + str(iter_num) + '.mat',
                    {'Wave': BVP_ALL})
        io.savemat('./' + args.save_path + f'/Result/WAVE_PR_ALL/' + rPPGNet_name + 'WAVE_PR_ALL' + '_iter' + str(iter_num) + '.mat',
                    {'Wave': BVP_PR_ALL})
        torch.save(deepcopy(TTAed_model.model), './' + args.save_path + f'/Result_Model/' + rPPGNet_name + '_iter' + str(iter_num))
        print('==> saveModel As ' + rPPGNet_name + '_iter' + str(iter_num))

        loss_mean = []
        Label_pr = []
        Label_gt = []
        HR_pr_temp = []
        HR_rel_temp = []
        HR_pr2_temp = []
        BVP_ALL = []
        BVP_PR_ALL = []

        test_start_time = timer()
        for tta_step, (data, bvp, HR_rel, _, _, _) in enumerate(tqdm(tgt_loader)):
            
            data = Variable(data).float().to(device=device)
            bvp = Variable(bvp).float().to(device=device)
            HR_rel = Variable(HR_rel).float().to(device=device)
            bvp = bvp.unsqueeze(dim=1)
            Wave = bvp

            # haodongli, for validation only
            _, _, Wave_pr, HR_pr, HR_C_pr, av = TTAed_model.model(data)

            if Target_name in ['VIPL', 'V4V', 'PURE']:
                HR_rel_temp.extend(HR_rel.data.cpu().numpy())
                HR_pr_temp.extend(HR_pr.data.cpu().numpy())
                BVP_ALL.extend(Wave.data.cpu().numpy())
                BVP_PR_ALL.extend(Wave_pr.data.cpu().numpy())
            else:
                temp, HR_rel = loss_func_SP(Wave, HR_rel)
                HR_rel_temp.extend(HR_rel.data.cpu().numpy())
                temp, HR_pr = loss_func_SP(Wave_pr, HR_pr)
                HR_pr_temp.extend(HR_pr.data.cpu().numpy())
                BVP_ALL.extend(Wave.data.cpu().numpy())
                BVP_PR_ALL.extend(Wave_pr.data.cpu().numpy())

        print(f'After TTA at {iter_num} [Full Test]')
        ME, STD, MAE, RMSE, MER, P = utils.MyEval(HR_pr_temp, HR_rel_temp)
        log.write(
            'Test Inter:' + str(iter_num) \
            + ' | ME:  ' + str(ME) \
            + ' | STD: ' + str(STD) \
            + ' | MAE: ' + str(MAE) \
            + ' | RMSE: ' + str(RMSE) \
            + ' | MER: ' + str(MER) \
            + ' | P '  + str(P) \
            + ' | testing time ' + time_to_str(timer() - test_start_time, 'min'))
        log.write('\n')

        rPPGNet_name = rPPGNet_name_raw
        io.savemat('./' + args.save_path + f'/Result/HR_pr/' + rPPGNet_name + 'HR_pr' + '_iter' + str(iter_num) + '.mat', {'HR_pr': HR_pr_temp})
        io.savemat('./' + args.save_path + f'/Result/HR_rel/' + rPPGNet_name + 'HR_rel' + '_iter' + str(iter_num) + '.mat', {'HR_rel': HR_rel_temp})
        io.savemat('./' + args.save_path + f'/Result/WAVE_ALL/' + rPPGNet_name + 'WAVE_ALL' + '_iter' + str(iter_num) + '.mat',
                    {'Wave': BVP_ALL})
        io.savemat('./' + args.save_path + f'/Result/WAVE_PR_ALL/' + rPPGNet_name + 'WAVE_PR_ALL' + '_iter' + str(iter_num) + '.mat',
                    {'Wave': BVP_PR_ALL})
        torch.save(deepcopy(TTAed_model.model), './' + args.save_path + f'/Result_Model/' + rPPGNet_name + '_iter' + str(iter_num))
        print('saveModel As ' + rPPGNet_name + '_iter' + str(iter_num))

    # TCLSCL_loss_log
    tta_log_path = f'./{args.save_path}/tta_loss_log.txt'
    tta_loss_avg = []
    for i in range(max_iter):
        tta_loss_temp = []
        for key in TCLSCL_loss_log:
            tta_loss_temp.append(TCLSCL_loss_log[key][i])
        tta_loss_avg.append(np.mean(tta_loss_temp))
    print("TTA Loss ->", tta_loss_avg)
    with open(tta_log_path, 'w') as f:
        for key in TCLSCL_loss_log:
            f.write(f'tta{key}\t')
            for loss in TCLSCL_loss_log[key]:
                f.write("%.8f\t"%loss)
            f.write('\n')

    # TODO haoodngli, to vis. the similarity of grads, to prove the significent improvement
    # of our "Prospective Adaptation" and "Retrospective Stabilization" based on priors
    # TCLSCL_grad_sim_log
    if args.TODO_MODE:
        tta_log_path = f'./{args.save_path}/tta_grad_sim_log.txt'
        with open(tta_log_path, 'w') as f:
            for key in TCLSCL_grad_sim_log:
                f.write(f'tta{key}\t')
                for info in TCLSCL_grad_sim_log[key]:
                    if type(info) == list or type(info) == np.ndarray:
                        for sub_info in info:
                            f.write("%.8f\t"%sub_info)
                    else:
                        f.write("%.8f\t"%info)
                f.write('\n')
        # grad. norm
        tta_log_path = f'./{args.save_path}/tta_grad_norm_log.txt'
        with open(tta_log_path, 'w') as f:
            for key in TCLSCL_grad_norm_log:
                f.write(f'tta{key}\t')
                for info in TCLSCL_grad_norm_log[key]:
                    if type(info) == list or type(info) == np.ndarray:
                        for sub_info in info:
                            f.write("%.8f\t"%sub_info)
                    else:
                        f.write("%.8f\t"%info)
                f.write('\n')
        # grad. std
        tta_log_path = f'./{args.save_path}/tta_grad_std_log.txt'
        with open(tta_log_path, 'w') as f:
            for key in TCLSCL_grad_std_log:
                f.write(f'tta{key}\t')
                for info in TCLSCL_grad_std_log[key]:
                    if type(info) == list or type(info) == np.ndarray:
                        for sub_info in info:
                            f.write("%.8f\t"%sub_info)
                    else:
                        f.write("%.8f\t"%info)
                f.write('\n')


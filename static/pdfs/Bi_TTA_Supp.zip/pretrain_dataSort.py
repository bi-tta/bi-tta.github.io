import cv2
import os
import numpy as np
import shutil
import pandas as pd
import scipy.io as scio
from scipy import interpolate
import scipy.io as io
import argparse



def get_args():
    parser = argparse.ArgumentParser(description='Train ',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument('-s', '--seed', dest='seed', type=int, default=0,
                        help='seed')
    parser.add_argument('-t', '--tgt', dest='tgt', type=str, default='VIPL',
                        help='the name of target domain: VIPL, COH, V4V, UBFC...')
    parser.add_argument('-m', '--method', dest='method', type=str, default='none',  # ttt++
                        help='the name of TTA: none, tent, sam, adadom ...')
    parser.add_argument('-i', '--iter', dest='iter', type=str, default=None)
    return parser.parse_args()

args = get_args()
Target_name = args.tgt

if args.iter == None:
    rPPGNet_name = 'rPPGNet_' + Target_name + 'TTA_' + args.method
else:
    rPPGNet_name = 'rPPGNet_' + Target_name + 'TTA_' + args.method + '_' + str(args.seed)


gt_name = 'BVP.mat'
savePath = f'./Pretrain_{Target_name}/'
if not os.path.exists(savePath):
    os.makedirs(savePath)
savePath = f'./Pretrain_{Target_name}/{args.seed}'
if not os.path.exists(savePath):
    os.makedirs(savePath)

Idex_files = r'/remote-home/share/haodongli/data/STMap/STMap_Index/' + Target_name
if args.iter == None:
    pr_path = r'./Result/' + rPPGNet_name + 'HR_pr_' + str(args.seed) + '.mat'
    gt_path = r'./Result/' + rPPGNet_name + 'HR_rel_' + str(args.seed) + '.mat'
else:
    pr_path = r'./Result/HR_pr/' + rPPGNet_name + 'HR_pr_' + 'iter' + str(args.iter) + '.mat'
    gt_path = r'./Result/HR_rel/' + rPPGNet_name + 'HR_rel_'+ 'iter' + str(args.iter) + '.mat'
print(Idex_files)
print(pr_path)
print(gt_path)

# Idex_files = r'/home/hlu/Data/STMap/STMap_Index/UBFC'
# gt_path = r'/home/hlu/Code/M2022/TransRPPG/4T1_DIG_CON_Sv3_SaveSig/Result/rPPGNet_UBFCSpatial0.5Temporal0.1WAVE_ALL.mat'
# pr_path = r'/home/hlu/Code/M2022/TransRPPG/4T1_DIG_CON_Sv3_SaveSig/Result/rPPGNet_UBFCSpatial0.5Temporal0.1WAVE_PR_ALL.mat'
pr = scio.loadmat(pr_path)['Wave']
pr = np.squeeze(np.array(pr.astype('float32')))
gt = scio.loadmat(gt_path)['Wave']
gt = np.squeeze(np.array(gt.astype('float32')))

files_list = os.listdir(Idex_files)
files_list = sorted(files_list)
temp = scio.loadmat(os.path.join(Idex_files, files_list[0]))
lastPath = str(temp['Path'][0])
pr_temp = []
gt_temp = []
print(pr.shape)
PERSON = 10000
for HR_index in range(pr.shape[0]):
    temp = scio.loadmat(os.path.join(Idex_files, files_list[HR_index]))
    nowPath = str(temp['Path'][0])
    Step_Index = int(temp['Step_Index'])
    if lastPath != nowPath:
        PERSON = PERSON + 1
        if pr_temp is None:
            print(nowPath)
            print(lastPath)
            pr_temp = []
            gt_temp = []
        else:
            print(lastPath)
            print(PERSON)
            io.savemat(savePath + str(PERSON) + 'pr_Wave.mat', {'Wave': pr_temp})
            io.savemat(savePath + str(PERSON) + 'gt_Wave.mat', {'Wave': gt_temp})
            pr_temp = []
            gt_temp = []
            pr_temp.append(pr[HR_index, :])
            gt_temp.append(gt[HR_index, :])
    else:
        pr_temp.append(pr[HR_index, :])
        gt_temp.append(gt[HR_index, :])
    lastPath = nowPath
# io.savemat('gt_ps.mat', {'HR': gt_ps})
# io.savemat('pr_ps.mat', {'HR': pr_ps})
# io.savemat('HR_rel.mat', {'HR': gt_av})
# io.savemat('HR_pr.mat', {'HR': pr_av})
# MyEval(gt_av, pr_av)

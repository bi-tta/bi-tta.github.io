import torch
from torch.optim import SGD
from typing import List

class CombinedCustomSGD(SGD):
    def __init__(self, params, lr, momentum=0, dampening=0, weight_decay=0, nesterov=False):
        super(CombinedCustomSGD, self).__init__(params, lr=lr, momentum=momentum, dampening=dampening, weight_decay=weight_decay, nesterov=nesterov)

    def step_no_update(self, zero_grad=True):
        updates = []  # to store the update amount of each layer
        grads = []

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    updates.append(None)
                    grads.append(None)
                    continue
                d_p = p.grad

                if group['weight_decay'] != 0:
                    d_p.add_(p, alpha=group['weight_decay'])
                if group['momentum'] != 0:
                    param_state = self.state[p]
                    if 'momentum_buffer' not in param_state:
                        buf = param_state['momentum_buffer'] = torch.clone(d_p).detach()
                    else:
                        buf = param_state['momentum_buffer']
                        buf.mul_(group['momentum']).add_(d_p, alpha=1 - group['dampening'])
                    if group['nesterov']:
                        d_p = d_p.add(buf, alpha=group['momentum'])
                    else:
                        d_p = buf

                updates.append(-group['lr'] * d_p)  # storing the update amount for each layer
                grads.append(d_p)
        
        # haodongli added on 2023年11月9日15点02分
        if zero_grad: self.zero_grad()

        return updates, grads

    def step_no_weight(self, closure=None):
        updates = []  # to store the update amount of each layer
        grads = []
        loss = None

        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for i, group in enumerate(self.param_groups):
            for i_p, p in enumerate(group['params']):
                if p.grad is None:
                    updates.append(None)
                    grads.append(None)
                    continue
                d_p = p.grad # * weights[i_p]  # apply custom weight

                if group['weight_decay'] != 0:
                    d_p.add_(p, alpha=group['weight_decay'])
                if group['momentum'] != 0:
                    param_state = self.state[p]
                    if 'momentum_buffer' not in param_state:
                        buf = param_state['momentum_buffer'] = torch.clone(d_p).detach()
                    else:
                        buf = param_state['momentum_buffer']
                        buf.mul_(group['momentum']).add_(d_p, alpha=1 - group['dampening'])
                    if group['nesterov']:
                        d_p = d_p.add(buf, alpha=group['momentum'])
                    else:
                        d_p = buf

                p.add_(d_p, alpha=-group['lr'])
                updates.append(-group['lr'] * d_p)  # storing the update amount for each layer
                grads.append(d_p)

        return loss, updates, grads

    def step(self, weights, closure=None):
        updates = []  # to store the update amount of each layer
        grads = []
        loss = None

        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for i, group in enumerate(self.param_groups):
            for i_p, p in enumerate(group['params']):
                if p.grad is None:
                    updates.append(None)
                    grads.append(None)
                    continue
                d_p = p.grad * weights[i_p]  # apply custom weight

                if group['weight_decay'] != 0:
                    d_p.add_(p, alpha=group['weight_decay'])
                if group['momentum'] != 0:
                    param_state = self.state[p]
                    if 'momentum_buffer' not in param_state:
                        buf = param_state['momentum_buffer'] = torch.clone(d_p).detach()
                    else:
                        buf = param_state['momentum_buffer']
                        buf.mul_(group['momentum']).add_(d_p, alpha=1 - group['dampening'])
                    if group['nesterov']:
                        d_p = d_p.add(buf, alpha=group['momentum'])
                    else:
                        d_p = buf
                p.add_(d_p, alpha=-group['lr'])
                
                updates.append(-group['lr'] * d_p)  # storing the update amount for each layer
                grads.append(d_p)

        return loss, updates, grads

    def step_with_grad(self, grads, closure=None):
        updates = []  # to store the update amount of each layer
        loss = None

        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for i, group in enumerate(self.param_groups):
            for i_p, p in enumerate(group['params']):
                if p.grad is None:
                    updates.append(None)
                    continue
                # d_p = p.grad * weights[i_p]  # apply custom weight
                # d_p = grads[i_p] * weights[i_p]  # apply custom weight
                d_p = grads[i_p]

                # if group['weight_decay'] != 0:
                #     d_p.add_(p, alpha=group['weight_decay'])
                # if group['momentum'] != 0:
                #     param_state = self.state[p]
                #     if 'momentum_buffer' not in param_state:
                #         buf = param_state['momentum_buffer'] = torch.clone(d_p).detach()
                #     else:
                #         buf = param_state['momentum_buffer']
                #         buf.mul_(group['momentum']).add_(d_p, alpha=1 - group['dampening'])
                #     if group['nesterov']:
                #         d_p = d_p.add(buf, alpha=group['momentum'])
                #     else:
                #         d_p = buf

                p.add_(d_p, alpha=-group['lr'])
                updates.append(-group['lr'] * d_p)  # storing the update amount for each layer

        return loss, updates, grads

    @torch.no_grad()
    def step_with_grad_nograd(self, grads, closure=None):
        updates = []  # to store the update amount of each layer
        loss = None

        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for i, group in enumerate(self.param_groups):
            for i_p, p in enumerate(group['params']):
                if p.grad is None:
                    updates.append(None)
                    continue
                # d_p = p.grad * weights[i_p]  # apply custom weight
                # d_p = grads[i_p] * weights[i_p]  # apply custom weight
                d_p = grads[i_p]

                # if group['weight_decay'] != 0:
                #     d_p.add_(p, alpha=group['weight_decay'])
                # if group['momentum'] != 0:
                #     param_state = self.state[p]
                #     if 'momentum_buffer' not in param_state:
                #         buf = param_state['momentum_buffer'] = torch.clone(d_p).detach()
                #     else:
                #         buf = param_state['momentum_buffer']
                #         buf.mul_(group['momentum']).add_(d_p, alpha=1 - group['dampening'])
                #     if group['nesterov']:
                #         d_p = d_p.add(buf, alpha=group['momentum'])
                #     else:
                #         d_p = buf

                p.add_(d_p, alpha=-group['lr'])

                updates.append(-group['lr'] * d_p)  # storing the update amount for each layer

        return loss, updates, grads


